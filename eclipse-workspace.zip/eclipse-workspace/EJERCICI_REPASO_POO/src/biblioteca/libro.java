package biblioteca;

public class libro {

	// atributos
	private String titulo;
	private String autor;
	private String isbn;
	private int paginas;
	private boolean prestado;

	// constructor sin parametros
	public libro() {

	}

	public libro(String titulo, String autor, String isbn, int paginas, boolean prestado) {

		super();
		this.titulo = titulo;
		this.autor = autor;
		this.isbn = isbn;
		this.paginas = paginas;
		this.prestado = prestado;
	}

	// getters y setters
	public String getTitulo() {
		return titulo;
	}

	public void setTitulo(String titulo) {
		this.titulo = titulo;
	}

	public String getAutor() {
		return autor;
	}

	public void setAutor(String autor) {
		this.autor = autor;
	}

	public String getIsbn() {
		return isbn;
	}

	public void setIsbn(String isbn) {
		this.isbn = isbn;
	}

	public int getPaginas() {
		return paginas;
	}

	public void setPaginas(int paginas) {
		this.paginas = paginas;
	}

	public boolean isPrestado() {
		return prestado;
	}

	public void setPrestado(boolean prestado) {
		this.prestado = prestado;
	}

	public void prestar() {

		prestado = true;

	}

	public void devolver() {

		prestado = false;

	}

	@Override
	public String toString() {
		return "libro [ titulo=" + titulo + " * autor=" + autor + " * isbn=" + isbn + " * paginas=" + paginas
				+ " * prestado=" + prestado + " ] ";
	}

}