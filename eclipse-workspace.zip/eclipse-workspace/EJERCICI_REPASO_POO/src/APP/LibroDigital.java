package APP;

import java.util.List;
import java.util.Scanner;
import biblioteca.libro;

public class LibroDigital extends libro {

	// protected permite que si en el futuro creas "LibroDigitalPDF", pueda usar este atributo
	protected String formato;

// constructor sin parametros
	public LibroDigital() {
		super();
	}

// constructor con parametros
	public LibroDigital(String titulo, String autor, String isbn, int paginas, boolean prestado, String formato) {
		
		super(titulo,autor,isbn,paginas,prestado);// Enviamos los datos a la clase libro
		this.formato = formato;
	}
	
// getters y setters
	public String getFormato() {
		return formato;
	}

	public void setFormato(String formato) {
		this.formato = formato;
	}

	   // MÉTODO EXCLUSIVO: Simple y directo de cambiar formato 
    public void cambiarFormato(String nuevoFormato) {
    	
        this.formato = nuevoFormato;
    }

   
//"Libro Digital" al principio y separado por "*"
@Override
public String toString() {

 return "Libro Digital * " + getTitulo() + " * " + getAutor() + " * " + getIsbn() +  " * " + getPaginas() + " * " + isPrestado() + " * " + formato;
}
}
