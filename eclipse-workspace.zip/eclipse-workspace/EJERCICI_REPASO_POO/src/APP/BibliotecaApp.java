package APP;

import java.util.*;
import java.io.File;
import biblioteca.libro;

public class BibliotecaApp {

	public static void main(String[] args) {

		// arrayList vacio
		List<libro> Listalibros = new ArrayList<>();

		// objetos de libros
		libro L1 = new libro();
		libro L2 = new libro();
		libro L3 = new libro();

		// libro-1
		L1.setTitulo("El Quijote");
		L1.setAutor("Cervantes");
		L1.setPaginas(605);

		// libro-2
		L2.setTitulo("Laas 48 leyes del poder");
		L2.setAutor("Robert Greene");
		L2.setPaginas(632);

		// Libro-3
		L3.setTitulo("los 3 cerditos");
		L3.setAutor(" Joseph Jacobs");
		L3.setPaginas(32);

		Listalibros.add(L1);
		Listalibros.add(L2);
		Listalibros.add(L3);

		// recorro los arrays de mis libros
		System.out.println("=== Libros de la biblioteca===\n");

		// Usamos 'l' como una variable temporal nueva para representar cada libro en la
		// lista
		for (libro l : Listalibros) {
			System.out.println(l.getTitulo() + " - " + l.getAutor() + " (" + l.getPaginas() + " págs)");

		}
		menu(Listalibros);// llamda del menu
	}

	public static void menu(List<libro> listalibros) {// menu co n opciones. . . .

		Scanner sc = new Scanner(System.in);
		int menu = 0;
		System.out.println("\n===menu===");

		do {
			System.out.println("1-Añadir libro"); // estas son operaciones CRUD
			System.out.println("2-Mostrar datos libro");
			System.out.println("3-Editar libro");
			System.out.println("4-Eliminar libro");
			System.out.println("5-cargar libros digitales");
			System.out.println("6-Mostrar libros digitales");
			System.out.println("7-cargar libros edicion limitada");
			System.out.println("8-mostrar libros edicion limitada");
			System.out.println("9-Cambiar Formato Digital");
			System.out.println("10-Cambiar Edición Limitada");
			System.out.println("11-Guardar (Sobrescribir) Ficheros");
			System.out.println("12-Salir");
			try {
				menu = Integer.parseInt(sc.nextLine());
			} catch (NumberFormatException e) {
				System.out.println("Error: Introduce un número válido.");
				continue;
			}

			switch (menu) {
			case 1:
				añadirLibro(listalibros, sc);
				break;
			case 2:
				mostrarDatos(listalibros);
				break;
			case 3:
				editarLibro(listalibros, sc);
				break;
			case 4:
				eliminarLibro(listalibros, sc);
				break;
			case 5:
				CargarLibrosdigitales(listalibros);
				break;
			case 6:
				mostrarLibrosDigitales(listalibros);
				break;
			case 7:
				// cargarLibrosEdicionLimitada(listalibros);
				break;
			case 8:
				// mostrarEdicionLimitada(listalibros);
				break;
			case 12:
				System.out.println("Saliendo del programa...");
				break;
			default:
				System.out.println("Opción no válida.");
			}

		} while (menu != 12);
	}

	// metodo de añadir libro
	private static void añadirLibro(List<libro> lista, Scanner sc) {
		// 1. Creamos la instancia del objeto
		libro nuevoLibro = new libro();

		// 2. Pedimos los datos al usuario
		System.out.print("Introduce el título: ");
		nuevoLibro.setTitulo(sc.nextLine());

		System.out.print("Introduce el autor: ");
		nuevoLibro.setAutor(sc.nextLine());

		System.out.print("Introduce el ISBN: ");
		nuevoLibro.setIsbn(sc.nextLine());

		int paginas;
		do {
			System.out.print("Introduce número de páginas (entre 50 y 500): ");
			paginas = Integer.parseInt(sc.nextLine());
			if (paginas < 50 || paginas > 500) {
				System.out.println("Error: El número de páginas debe estar entre 50 y 500.");
			}
		} while (paginas < 50 || paginas > 500);
		nuevoLibro.setPaginas(paginas);

		// 3. Lo añadimos a la lista recibida por parámetro
		lista.add(nuevoLibro);
		System.out.println("¡Libro añadido con éxito!");
	}

	// metodo mostrar datos
	private static void mostrarDatos(List<libro> listalibros) {

		for (int i = 0; i < listalibros.size(); i++) {
			System.out.println(listalibros.get(i).toString());

		}
	}

	// metodo para editar libro
	private static void editarLibro(List<libro> listalibros, Scanner sc) {

		System.out.print("Introduce el título del libro a editar: ");
		String titutloBuscar = sc.nextLine();
		boolean encontrado = false;
		for (libro l : listalibros) {
			if (l.getTitulo().equalsIgnoreCase(titutloBuscar)) {
				encontrado = true;
				System.out.print("Nuevo título (dejar en blanco para no cambiar): ");
				String nuevoTitulo = sc.nextLine();
				if (!nuevoTitulo.isEmpty()) {
					l.setTitulo(nuevoTitulo);
				}

				System.out.print("Nuevo autor (dejar en blanco para no cambiar): ");
				String nuevoAutor = sc.nextLine();
				if (!nuevoAutor.isEmpty()) {
					l.setAutor(nuevoAutor);
				}

				System.out.print("Nuevo ISBN (dejar en blanco para no cambiar): ");
				String nuevoIsbn = sc.nextLine();
				if (!nuevoIsbn.isEmpty()) {
					l.setIsbn(nuevoIsbn);
				}

				System.out.print("Nuevas páginas (dejar en blanco para no cambiar): ");
				String paginasInput = sc.nextLine();
				if (!paginasInput.isEmpty()) {
					int nuevasPaginas = Integer.parseInt(paginasInput);
					l.setPaginas(nuevasPaginas);
				}

				System.out.println("¡Libro actualizado con éxito!");
				break;
			}
		}

		if (!encontrado) {
			System.out.println("Libro no encontrado.");
		}
	}

	// metodo eliminar libro
	private static void eliminarLibro(List<libro> listalibros, Scanner sc) {
		System.out.print("Introduce el título del libro a eliminar: ");
		String tituloBuscar = sc.nextLine();

		// Elimina si el título coincide (ignorando mayúsculas/minúsculas)
		boolean eliminado = listalibros.removeIf(l -> l.getTitulo().equalsIgnoreCase(tituloBuscar));

		if (eliminado) {
			System.out.println("¡Libro eliminado con éxito!");
		} else {
			System.out.println("Libro no encontrado.");
		}
	}

	// cargar los libros digitales metodo
	private static void CargarLibrosdigitales(List<libro> listalibros) {
		try (Scanner fs = new Scanner(new File("./fichero_librosDigitales/librosDigitales.txt"))) {// leemos los
																									// ficheros con
																									// scanner
			fs.nextLine();// saltod e cabecera, lo de titulo, autor etc
			while (fs.hasNextLine()) {
				String linea = fs.nextLine();
				String[] partes = linea.split(":");

				// creacion del objeto
				LibroDigital ld = new LibroDigital(partes[0], partes[1], partes[2], Integer.parseInt(partes[3]),
						Boolean.parseBoolean(partes[4]), partes[5]);
				listalibros.add(ld);
			}
			System.out.println("\ndigitales cargados exitosamente.....\n");
		} catch (Exception e) {
			System.out.println("error al leer" + e.getMessage());
		}
	}

	// mostrar libros digitales metodo
	private static void mostrarLibrosDigitales(List<libro> listalibros) {

		try (Scanner mostrar = new Scanner(new File("./fichero_librosDigitales/librosDigitales.txt"))) {// leemos los
																										// ficheros con
																										// scanner
			mostrar.nextLine();// saltamos la cabecera
			while (mostrar.hasNextLine()) {
				String linea = mostrar.nextLine();
				String partes[] = linea.split(":");// separamos
				System.out.println(linea + "\n");// imprimo las lineas de mi fichero
			}
		} catch (Exception e) {
			System.out.println("error al mostrar contenido" + e.getMessage());
		}

	}
}