package APP;

import biblioteca.libro;

public final class LibroEdicionLimitada extends libro {

   // atributos
	private int numeroEdicion;
	private int ejemplares;

    // constructor sin parametros
    public LibroEdicionLimitada() {
    	super();
    	
    }

    // constructor con parametros
    public LibroEdicionLimitada(String titulo, String autor, String isbn, int paginas, boolean prestado, int numeroEdicion, int ejemplares) {
        super(titulo, autor, isbn, paginas, prestado);
        this.numeroEdicion = numeroEdicion;
        this.ejemplares = ejemplares;
    }
    
    // getters y setters
    public int getNumeroEdicion() {
		return numeroEdicion;
	}

	public void setNumeroEdicion(int numerEdicion) {
		this.numeroEdicion = numerEdicion;
	}

	public int getEjemplares() {
		return ejemplares;
	}

	public void setEjemplares(int ejemplares) {
		this.ejemplares = ejemplares;
	}
	
	//Crear el método cambiarNumeroEdicion(int nuevoNumero).
	public void cambiarNumeroEdicion(int nuevoNumero) {
		
		this.numeroEdicion=nuevoNumero;
	}
	
    @Override
    public String toString() {
 return "Libro Edicion Limitada * " + getTitulo() + " * " + getAutor() + " * " + getIsbn() + " * " + getPaginas() + " * " + isPrestado() + " * " + numeroEdicion + " * " + ejemplares;
    }
}
	
