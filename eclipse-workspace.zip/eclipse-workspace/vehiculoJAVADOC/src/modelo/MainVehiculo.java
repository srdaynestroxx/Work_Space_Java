package modelo;

public class MainVehiculo {
	public static void main(String[] args) { 
        Vehiculo v1 = new Vehiculo("Seat", "Ibiza", 2018, 'C', 95, 1200f); 
        Vehiculo v2 = new Vehiculo("Audi", "A3", 2020, 'C', 150, 1350f); 
 
        System.out.println("Datos v1:");         v1.mostrarDatos(); 
        System.out.println(); 
 
        System.out.println("Datos v2:");         v2.mostrarDatos(); 
        System.out.println(); 
 
        System.out.println("¿v2 es más nuevo que v1? " + 
v2.esMasNuevoQue(v1)); // true 
        System.out.println("Tipo largo v1: " + v1.getTipoFormatoLargo()); // coche 
 
        float litros = 35f;         float km = 500f; 
        float consumo = v1.consumoMedioPor100Km(litros, km);         System.out.printf("Consumo medio v1 para %.0f km y %.1f L: %.2f L/100km%n", km, litros, consumo); 
        System.out.println("v2 tiene alta potencia (>150 CV)? " + v2.tieneAltaPotencia()); // false (150 no > 150) 
    }
}
