	package modelo;

	/**
	 * @author Daymer Pineda 
	 * @since 7/11/2025
	 * @version 1.0.1 * 
	 */
	/**
	 * programa de vehiculo que te da los datos de los distintos coches 
	 * a continuacion podemos ver los sigientes datos que poseen cada coche 
	 */
public class Vehiculo {
	private String marca;
	private String modelo;
	private int data;
	private char tipo; // 'C' coche, 'M' moto, 'T' transporte 
	private int potenciaCV; 
	private float pesoKg;

	/**
	 * constructor vacio Permite crear una instancia (objeto)
	 */
	public Vehiculo() {
	}

	/**
	 * constructor con  parametros: a diferencia del vacio tiene valores dentro de si,sirve 
	 * para garantizar que un objeto se inicialice en un estado válido y completo desde el momento de su creación
	 * 
	 * @param marca
	 * @param modelo
	 * @param data
	 * @param tipo
	 * @param potenciaCV
	 * @param pesoKg
	 */
	public Vehiculo(String marca, String modelo, int data, char tipo, int potenciaCV, float pesoKg) {
		this.marca = marca;
		this.modelo = modelo;
		this.data = data;
		this.tipo = tipo;
		this.potenciaCV = potenciaCV;
		this.pesoKg = pesoKg;
	}

	/**
	 * Obtiene la marca del vehículo.+
	 * @return La cadena de texto (String) que representa la marca actual del coche.
	 */
	public String getMarca() {
		return marca;
	}

	/**
	 * Establece (modifica) la marca del vehículo. 
	 * @param marca El nuevo nombre de la marca que se asignará al coche.
	 */
	public void setMarca(String marca) {
		this.marca = marca;
	}

	/**
	 * obtiene el modelo del vehiculo
	 * @return devuelve el String que representa el modelo del coche 
	 */
	public String getModelo() {
		return modelo;
	}

	/**
	 * modifica el modleo del vehiculo 
	 * @param modelo el nuevo modelo que se le asignara al coche 
	 */
	public void setModelo(String modelo) {
		this.modelo = modelo;
	}

	/**
	 * obtiene la data del vehiculo 
	 * @return la fecha que se le asignara al coche 
	 */
	public int getData() {
		return data;
	}

	/**
	 * modifica la data del vehiculo ( año ) 
	 * @param anio que se le asignara al coche 
	 */
	public void setData(int anio) {
		this.data = data;
	}
	
	/**
	 * obtiene el tipo del vehiculo
	 * @return el tipo wue se le asignara al equipo
	 */
	public char getTipo() {
		return tipo;
	}

	/**
	 * Modifica el tipo del equipo.
	 * 
	 * @param tipo El carácter que representa el tipo del coche.
	 */
	public void setTipo(char tipo) {
		this.tipo = tipo;
	}

	/**
	 * obtiene la potencia del vehiculo 
	 * @return la pote
	 */
	public int getPotenciaCV() {
		return potenciaCV;
	}

	public void setPotenciaCV(int potenciaCV) {
		this.potenciaCV = potenciaCV;
	}

	public float getPesoKg() {
		return pesoKg;
	}

	public void setPesoKg(float pesoKg) {
		this.pesoKg = pesoKg;
	}

	public boolean esMasNuevoQue(Vehiculo v) {
		return this.data > v.getData();
	}

	public String getTipoFormatoLargo() {
		switch (Character.toUpperCase(tipo)) {
		case 'C':
			return "coche";
		case 'M':
			return "moto";
		case 'T':
			return "transporte";
		default:
			return "desconocido";
		}
	}

	public float consumoMedioPor100Km(float litros, float km) {
		if (km <= 0) throw new IllegalArgumentException("La distancia (km) debe ser mayor que 0");
		return (litros / km) * 100f;
		}
		public boolean tieneAltaPotencia() {
		return this.potenciaCV > 150;
		}
		public void mostrarDatos() {
		System.out.println("Marca: " + marca);
		System.out.println("Modelo: " + modelo);
		System.out.println("Año: " + data);
		System.out.println("Tipo: " + getTipoFormatoLargo());
		System.out.println("Potencia (CV): " + potenciaCV);
		System.out.println("Peso (kg): " + pesoKg);
		}
		}