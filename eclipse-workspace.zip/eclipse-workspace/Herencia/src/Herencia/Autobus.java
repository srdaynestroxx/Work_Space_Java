package Herencia;

public class Autobus extends Vehiculo {
	private boolean busEscolar;
	private int viajerosEnPie;

	public Autobus() {
	}

	public Autobus(String matricula, String modelo, int potencia, int numeroPlazas, Color color,
			boolean busEscolar, int viajerosEnPie) {
		super(matricula, modelo, potencia, numeroPlazas, color);
		this.busEscolar = busEscolar;
		this.viajerosEnPie = viajerosEnPie;
	}

	public boolean isBusEscolar() {
		return busEscolar;
	}

	public void setBusEscolar(boolean busEscolar) {
		this.busEscolar = busEscolar;
	}

	public int getViajerosEnPie() {
		return viajerosEnPie;
	}

	public void setViajerosEnPie(int viajerosEnPie) {
		this.viajerosEnPie = viajerosEnPie;
	}

	@Override
	public String toString() {
		return "Autobusa [busEscolar=" + busEscolar + ", viajerosEnPie=" + viajerosEnPie + ", getMatrikula()="
				+ getMatricula() + ", getModelo()=" + getModelo() + ", getPotencia()=" + getPotencia()
				+ ", getNumeroPlazas()=" + getNumeroPlazas() + ", getColor()=" + getColor() + "]";
	}

}

