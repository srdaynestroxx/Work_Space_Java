package Herencia;

public enum Tipo {
	isósceles, escaleno, equilátero
}
