package Herencia;

public class Taxi extends Vehiculo {//la calve para la herencia es extends 
	private int numeroLicencia;

	public Taxi() {
	}

	public Taxi(String matricula, String modelo, int potencia, int numeroPlazas, Color color,
			int numeroLicencia) {
		super(matricula, modelo, potencia, numeroPlazas, color);
		this.numeroLicencia = numeroLicencia;
	}

	public int getNumeroLicencia() {
		return numeroLicencia;
	}

	public void setNumeroLicencia(int numeroLicencia) {
		this.numeroLicencia = numeroLicencia;
	}

	@Override
	public String toString() {
		return "Taxi [numeroLicencia=" + numeroLicencia + ", matricula()=" + getMatricula() + ", modelo()="
				+ getModelo() + ", potencia()=" + getPotencia() + ", numeroPlazas()=" + getNumeroPlazas()
				+ ", color()=" + getColor() + "]";
	}

}
