package Herencia;

public class Triangulo extends Figura2D {//la clave para la herencia es extends 
	
	private Tipo tipo;
	
	public Triangulo(){
		
	}

	
	public Tipo getTipo() {
		return tipo;
	}

	public void setTipo(Tipo tipo) {
		this.tipo = tipo;
	}
	
	
	public Triangulo(float anchura, float altura) {

		CalcularArea(anchura, altura);
		Tipotriangulo(tipo);
	}

	
	private void CalcularArea(float anchura, float altura) {
		// TODO Auto-generated method stub
		
		
	}
	private void Tipotriangulo(Tipo tipo2) {
		// TODO Auto-generated method stub
		
	}



}
