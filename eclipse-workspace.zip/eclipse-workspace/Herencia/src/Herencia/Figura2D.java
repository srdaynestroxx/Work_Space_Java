package Herencia;

public class Figura2D {
	
	protected float anchura;
	protected float altura; 
//cuando usas protected puedes heredar estos atributos con extends a otras clases, a diferencia de si usas private 

	public 	Figura2D(){
	}
	
	public Figura2D(float anchura, float altura) {
		
		this.anchura=anchura;
		this.altura= altura;
	}
	
	//getter y setter 
	public float getAnchura() {
		return anchura;
	}

	public void setAnchura(float anchura) {
		this.anchura = anchura;
	}

	public float getAltura() {
		return altura;
	}

	public void setAltura(float altura) {
		this.altura = altura;
	}
		
	//dimensiones figura
	public String Dimensiones() {
		return "Figura2D anchura=" + anchura + ", altura=" + altura + "";
	}
	
}
