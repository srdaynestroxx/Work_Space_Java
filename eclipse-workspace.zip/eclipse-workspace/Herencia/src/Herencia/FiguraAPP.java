package Herencia;

public class FiguraAPP {

}
