package Herencia;

public class Vehiculo {
	protected String matricula;
	protected String modelo;//caundo usas protected puedes heredar estos atributos con extends a otras calses, a diferencia de si usas private 
	private int potencia;
	private int numeroPlazas;
	private Color color;

	public Vehiculo() {
	}

	public Vehiculo(String matricula, String modelo, int potencia, int numeroPlazas, Color color) {
		this.matricula = matricula;
		this.modelo = modelo;
		this.potencia = potencia;
		this.numeroPlazas = numeroPlazas;
		this.color = color;
	}

	public String getMatricula() {
		return matricula;
	}

	public void setMatricula(String matricula) {
		this.matricula = matricula;
	}

	public String getModelo() {
		return modelo;
	}

	public void setModelo(String modelo) {
		this.modelo = modelo;
	}

	public int getPotencia() {
		return potencia;
	}

	public void setPotencia(int potencia) {
		this.potencia = potencia;
	}

	public int getNumeroPlazas() {
		return numeroPlazas;
	}

	public void setNumeroPlazas(int numeroPlazas) {
		this.numeroPlazas = numeroPlazas;
	}

	public String getColor() {
		return color.name();
	}

	public void setColor(Color color) {
		this.color = color;
	}
}
