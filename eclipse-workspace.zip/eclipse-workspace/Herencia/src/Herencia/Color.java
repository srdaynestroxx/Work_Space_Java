package Herencia;

public enum Color {
	BLANCO, NEGRO, AZUL
}
