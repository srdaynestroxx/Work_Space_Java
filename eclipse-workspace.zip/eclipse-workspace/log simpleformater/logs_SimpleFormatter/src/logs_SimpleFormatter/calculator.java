package logs_SimpleFormatter;

public class calculator {
//ejercicio con javadoc incluido
    /**
     * Realiza la suma de dos números.
     * @param a Primer operando.
     * @param b Segundo operando.
     * @return La suma de a y b.
     */
    public double add(double a, double b) {
        return a + b;
    }

    /**
     * Realiza la resta de dos números.
     * @param a Primer operando.
     * @param b Segundo operando.
     * @return La resta de a y b.
     */
    public double sub(double a, double b) {
        return a - b;
    }

    /**
     * Realiza la multiplicación de dos números.
     * @param a Primer operando.
     * @param b Segundo operando.
     * @return La multiplicación de a y b.
     */
    public double mul(double a, double b) {
        return a * b;
    }

    /**
     * Realiza la división de dos números.
     * @param a Numerador.
     * @param b Denominador.
     * @return La división de a entre b.
     * @throws ArithmeticException Si el denominador (b) es cero.
     */
    public double div(double a, double b) throws ArithmeticException {
        if (b == 0) {
            throw new ArithmeticException("División por cero no permitida");
        }
        return a / b;
    }
}