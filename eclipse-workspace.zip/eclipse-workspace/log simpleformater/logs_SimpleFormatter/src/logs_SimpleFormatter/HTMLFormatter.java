package logs_SimpleFormatter;

import java.util.logging.Formatter;
import java.util.logging.LogRecord;
import java.util.logging.Level;
import java.util.Date;
import java.text.SimpleDateFormat;


//Esta clase es la clave. Extenderá java.util.logging.Formatter y
//debe escribir el código HTML de apertura y cierre (getHead y getTail) y el formato del mensaje (format).

public class HTMLFormatter extends Formatter {

    private final SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

    /**
     * Formatea el LogRecord en una fila de tabla HTML.
     */
    @Override
    public String format(LogRecord record) {
        // Usamos una fila (<tr>) para cada mensaje de log
        StringBuilder sb = new StringBuilder();
        
        // Determinar el color de fondo de la fila basado en el nivel
        String color = (record.getLevel() == Level.SEVERE) ? "red" : "blue";
        
        sb.append("<tr style=\"background-color: ")
          .append(record.getLevel() == Level.SEVERE ? "#FF9999" : "#CCCCFF") // Rojo claro para SEVERE, Azul claro para otros
          .append(";\">");
        
        // 1. Hora del evento
        sb.append("<td>").append(dateFormat.format(new Date(record.getMillis()))).append("</td>");
        
        // 2. Nivel del log (en negrita)
        sb.append("<td><strong><span style=\"color: ")
          .append(color)
          .append(";\">")
          .append(record.getLevel().getLocalizedName())
          .append("</span></strong></td>");
        
        // 3. Mensaje
        sb.append("<td>").append(formatMessage(record)).append("</td>");
        
        sb.append("</tr>\n");
        return sb.toString();
    }

    /**
     * Devuelve la cabecera HTML (inicio del archivo).
     */
    @Override
    public String getHead(java.util.logging.Handler h) {
        return "<!DOCTYPE html>\n" +
               "<html>\n" +
               "<head>\n" +
               "<title>Historial de Operaciones</title>\n" +
               "<style>body {font-family: Arial, sans-serif;} table {width: 80%; border-collapse: collapse; margin-top: 20px;} th, td {border: 1px solid #ccc; padding: 8px; text-align: left;}</style>\n" +
               "</head>\n" +
               "<body>\n" +
               "<h2>Registro de Operaciones de Calculadora</h2>\n" +
               "<table>\n" +
               "<tr><th>Hora</th><th>Nivel</th><th>Mensaje</th></tr>\n";
    }

    /**
     * Devuelve el pie HTML (cierre del archivo).
     */
    @Override
    public String getTail(java.util.logging.Handler h) {
        return "</table>\n" +
               "</body>\n" +
               "</html>";
    }
}