package logs_SimpleFormatter;

import java.io.File;
import java.io.IOException;
import java.util.logging.FileHandler;
import java.util.logging.Level;
import java.util.logging.Logger;

// Renombramos la clase para este ejercicio
public class MainHTMLLogger {
	
    // 1. Corregido: Referencia a la clase Calculator (asumiendo C mayúscula por convención)
    private static final Logger logger = Logger.getLogger(calculator.class.getName()); 

    public static void main(String[] args) {
        
        // Desactivar useParentHandlers
        logger.setUseParentHandlers(false);

        // Establecer el nivel de log para el Logger (INFO)
        logger.setLevel(Level.INFO); 
        
        // Creamos la carpeta 'logs' si no existe
        new File("./logs").mkdirs();

        // Toda la configuración del FileHandler debe ir en un bloque try-catch
        try {
            // 1. Crear el FileHandler
            FileHandler fileHandler = new FileHandler("./logs/historial.html");
            
            // 2. Asignar el nivel (INFO)
            fileHandler.setLevel(Level.INFO); 
            
            // 3. ASIGNAR EL FORMATTER HTML
            fileHandler.setFormatter(new HTMLFormatter());
            
            // 4. Añadir el Handler
            logger.addHandler(fileHandler);
            
            logger.info("El servicio de logging HTML ha sido configurado.");
            
        } catch (IOException e) {
            // Si falla la creación del archivo
            System.err.println("Error grave al configurar el FileHandler: " + e.getMessage());
            logger.log(Level.SEVERE, "No se pudo crear el archivo de log.", e);
            return;
        }
        
        // --- Lógica de la aplicación con logs (Restaurada) ---
        // 2. Corregido: Inicialización correcta de la calculadora y variables
        calculator calculator = new calculator();
        double num1 = 10.0;
        double num2 = 5.0;
        double result;

        // Suma
        logger.info("Iniciando operación: Suma"); 
        result = calculator.add(num1, num2);
        logger.info("Resultado de la suma: " + result); 

        // Resta
        logger.info("Iniciando operación: Resta");
        result = calculator.sub(num1, num2);
        logger.info("Resultado de la resta: " + result);

        // Multiplicación
        logger.info("Iniciando operación: Multiplicación");
        result = calculator.mul(num1, num2);
        logger.info("Resultado de la multiplicación: " + result);

        // División (Caso Exitoso)
        logger.info("Iniciando operación: División (" + num1 + " / " + num2 + ")");
        try {
            result = calculator.div(num1, num2);
            logger.info("Resultado de la división: " + result);
        } catch (ArithmeticException e) {
             logger.log(Level.SEVERE, "Excepción en división exitosa (no debería ocurrir): " + e.getMessage());
        }

        // División (Caso de División por Cero)
        double num3 = 0.0;
        logger.info("Iniciando operación: División (" + num1 + " / " + num3 + ")");

        // Manejar la excepción de división por cero
        try {
            result = calculator.div(num1, num3);
            logger.info("Resultado de la división: " + result);
        } catch (ArithmeticException e) {
            // Registrar un mensaje SEVERE en caso de error
            logger.log(Level.SEVERE, "Error detectado: " + e.getMessage()); 
        }
        
        logger.info("Todas las operaciones han finalizado.");
    }
}