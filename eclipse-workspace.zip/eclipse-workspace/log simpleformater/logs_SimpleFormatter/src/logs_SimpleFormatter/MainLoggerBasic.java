package logs_SimpleFormatter;

public class MainLoggerBasic {

    public static void main(String[] args) {
        
        calculator calculator = new calculator();
        double num1 = 10.0;
        double num2 = 5.0;
        double result;

        result = calculator.add(num1, num2);
        System.out.println("Suma: " + result);

        result = calculator.sub(num1, num2);
        System.out.println("Resta: " + result);

        result = calculator.mul(num1, num2);
        System.out.println("Multiplicación: " + result);

        try {
            result = calculator.div(num1, num2);
            System.out.println("División exitosa: " + result);
        } catch (ArithmeticException ignored) {
            
        }

        double num3 = 0.0;

        try {
            result = calculator.div(num1, num3);
            System.out.println("División por cero: " + result); // No se ejecutará
        } catch (ArithmeticException e) {
            System.err.println("Error detectado: " + e.getMessage()); 
        }
    }
}