package PRUEBA_REPASO;

import java.util.Scanner;

public class IF_repaso_5 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Scanner daymer = new Scanner(System.in);
		
//		 Leer un número y decir si esta entre 0 y 10 inclusive.
		
		int numero = 0;
		
		System.out.println("Introduce un numero :");
		int num = daymer.nextInt();
		
		if(num <=10) {
			
			System.out.println("el numero introducido esta entre 0-10");
		}else {
			
			System.out.println("el numero se sale del rango. ");
		}

	}

}
