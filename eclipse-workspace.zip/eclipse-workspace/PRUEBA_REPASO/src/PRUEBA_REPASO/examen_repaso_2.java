package PRUEBA_REPASO;

import java.util.Scanner;

public class examen_repaso_2 {

	public static void main(String[] args) {

//		Se quiere gestionar información sobre estudiantes matriculados en diferentes
//		cursos. Escribir un programa en Java que haga lo siguiente:
//		1. Preguntar por pantalla cuántos estudiantes hay en total.
//		2. Pedir los nombres de los estudiantes, la edad de cada uno y el curso en el
//		que están matriculados. Guardar los datos en 3 arrays distintos
//		3. Mostrar por pantalla el estudiante mayor y el estudiante menor
//	 	4. Calcular y mostrar la edad media de los estudiantes
//		5. Pedir al usuario que introduzca un curso y mostrar todos los estudiantes
//		que están en ese curso. Si no hay ninguno, mostrar un mensaje avisando
//		de ello.
		
		Scanner daymer = new Scanner(System.in);
		
		System.out.println("cuántos estudiantes hay en total ? ");
		int estudiantes = daymer.nextInt(); //variable int con la que capturo los estudiantes en total
		
		  String[] nombres = new String[estudiantes]; //guardo los datos de esos estudiantes en mis arrays 
		  int[] edad = new int[estudiantes];
		  String[] cursoMatricula = new String[estudiantes];
		
		  //for para rellenar los datops de misd arrays 
		  //indiceEstudiantes < estudiantes →
		 // el bucle se repite exactamente tantas veces como 
		  //estudiantes haya introducido el usuario.(aqui si use ia, solo en  esa pequeña comparacion del for)
		
		  for(int indiceEstudiantes = 0; indiceEstudiantes < estudiantes; indiceEstudiantes++ ) {
//			  según los estudiantes que el usuario escriba, 
//			  el ciclo se repite ese mismo número de veces.
			  System.out.println("Introduce el nombre del estudiante : " + (indiceEstudiantes + 1) + ": ");
			  nombres[indiceEstudiantes]= daymer.next();
			  
			  System.out.println("cual es el curso donde estan matriculados "+ (indiceEstudiantes + 1) + ": ");
			  cursoMatricula[indiceEstudiantes] = daymer.next();
			  
			  System.out.println("cual es la edad de los estudiantes ?: "+ (indiceEstudiantes + 1) + ": ");
			  edad[indiceEstudiantes] = daymer.nextInt();
			  daymer.nextLine();//para tener cuidaod con el salto de linea combinado de nextInt y nexline
		  }
		  
		  //ESTUDIANTE MAYOR Y ESTUDIANTYE MENOR
		  int estudianteMayor=0;
		  int estudianteMenor=0;
		  int edadMax= edad[0];
		  int edadMin= edad[0];
		  
		  //for estudiante mayor 
		  for(int i =1; i < estudiantes; i++) {
			  if(edad[i] > edadMax) {
				  edadMax = edad[i];
				  estudianteMayor = i;
			  }
		  }
			// Buscar el estudiante con menor edad
			  for (int i = 1; i < estudiantes; i++) {
			      if (edad[i] < edadMin) {
			          edadMin = edad[i];
			          estudianteMenor = i;
			      }
			  }
	// Mostrar resultados
		  System.out.println("\nEl estudiante mayor es: " + nombres[estudianteMayor] + 
			                     " con " + edadMax + " años, del curso " + cursoMatricula[estudianteMayor]);

		 System.out.println("El estudiante menor es: " + nombres[estudianteMenor] + 
			                     " con " + edadMin + " años, del curso " + cursoMatricula[estudianteMenor]);
		
		// Calcular la media de las edades
		 double promedioEdades = media(edad);
		 
		 // Mostrar el resultado
		 System.out.println("\nLa edad media de los estudiantes es: " + promedioEdades);
		 
			
//			5. Pedir al usuario que introduzca un curso y mostrar todos los estudiantes
//			que están en ese curso. Si no hay ninguno, mostrar un mensaje avisando
//			de ello.
		 
			System.out.println("introduce un curso y te dire los alumnos que estan en el: ");
			String BuscarCurso = daymer.next();
			
			boolean encontrado = false;
			
			System.out.println("\nEstudiantes matriculados en el curso " + BuscarCurso + ":");
			
			for(int i=0; i < estudiantes ; i++) {
				if(cursoMatricula[i].equalsIgnoreCase(BuscarCurso)) {
					  System.out.println("- " + nombres[i] + " (" + edad[i] + " años)");
				        encontrado = true;
				}else if(!encontrado) {
					System.out.println("no hayb estudiasntes matriculasdos ene se curso");
				}
			}
daymer.close();
		  }
	
	 // edad media de los estudiantes ( USANDO METODOS LOGRE APRENDER A SACAR LA MEDIA ( VISTO EN YT)
	public static double media(int edad[]) {
		
		double media=0.0; 
		double suma=0.0;
		for(int i =0; i<edad.length; i++) {
			suma += edad[i];
		}
		media = suma / edad.length;
		return media;
		
	}

	
	}