package PRUEBA_REPASO;

import java.util.Scanner;

public class examen_repaso {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner daymer = new Scanner(System.in);

//		se quiere llevar un registro de libros en una biblioteca. 
//		Escribir un programa en java que haga los siguiente:

//		1.preguntar por pantalla cuantos libros se van a registrar.

//		2.pedir por pantalla los titulos de los libros, los nombres de los autores y los 
//		años de publicación. guarda estos datos en 3 arrays distintos.

//		3.mostrar por pantala el libro mas antiguo y el libro mas  reciente de la biblioteca 

//		4.calcular la media de los libros 

//		5.pedir al usuario que introduzca el nombre de un autor y mostrar todos los libros escritos por
//		ese autor. Si no hay ninguno, mostrar un mensaje avisando de ello.

//		extras: 
//		ºmostrar por pantalla toods los autores sin repeticiones, ordenados albafeticamente 
//		ºcontar y mostrar cuantos libros hay cada autor 

		System.out.println("cuantos libros quieres registrar ?");
		int numLibros = daymer.nextInt();
		daymer.nextLine(); // Limpiar el buffer del scanner

		// Arrays para meter libros, autores, titulo y años.
		String[] titulos = new String[numLibros];
		String[] autores = new String[numLibros];
		int[] anios = new int[numLibros];

		// for para rellenar los arrays con datos de los libros.
		for (int i = 0; i < numLibros; i++) {
			System.out.println("dame el título del libro: " + (i + 1) + ": ");
			titulos[i] = daymer.nextLine();

			System.out.println("dame el autor del libro: " + (i + 1) + ": ");
			autores[i] = daymer.nextLine();

			System.out.println("dame los años del libro: " + (i + 1) + ": ");
			anios[i] = daymer.nextInt();
			daymer.nextLine(); // Limpiar el buffer del scanner
		}

		// ENCONTRAR LIBRO MÁS ANTIGUO Y MÁS RECIENTE
		// Se inicializan con el primer elemento para evitar el problema de
		// MAX_VALUE/MIN_VALUE.
		int anioMax = anios[0];
		int indiceReciente = 0;
		int anioMin = anios[0];
		int indiceAntiguo = 0;

		for (int i = 1; i < numLibros; i++) { // Se empieza desde el segundo elemento (índice 1).
			if (anios[i] > anioMax) {
				anioMax = anios[i];
				indiceReciente = i;
			}
			if (anios[i] < anioMin) {
				anioMin = anios[i];
				indiceAntiguo = i;
			}
		}

		System.out.println("El libro más reciente es: " + titulos[indiceReciente] + " (" + anios[indiceReciente] + ")");
		System.out.println("El libro más antiguo es: " + titulos[indiceAntiguo] + " (" + anios[indiceAntiguo] + ")");

		// CALCULAR LA MEDIA
		int sumaAnios = 0;
		for (int i = 0; i < numLibros; i++) {
			sumaAnios += anios[i];
		}

		// (double) para que la división sea precisa y no entera.
		double mediaAnios = (double) sumaAnios / numLibros;
		System.out.println("La media de los años de publicación es: " + mediaAnios);

		System.out.println("\nintroduce el nombre del autor para ver sus libros escritos");
		String BuscaAutor = daymer.next();

		boolean encontrado = false;

		System.out.println("libros de " + BuscaAutor + ":");

		//5
		for (int i = 0; i < numLibros; i++) {
			if (autores[i].equalsIgnoreCase(BuscaAutor)) {
				System.out.println(" " + titulos[i] + " (" + anios[i] + ")");
				encontrado = true;
			}
		}
		if (!encontrado) {
			System.out.println("el resultado no fue encontrado");
		}
		
		
	}
}
