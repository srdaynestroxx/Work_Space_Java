package PRUEBA_REPASO;

public class for_repaso_3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
//		Escribir un programa que imprima los 10 primeros
//		números enteros empezando por el cero, excepto el 5. (Utilizando for )
		
		int numero= 11;
		
		for(int i = 0; i<numero ;i++) {
			
			if(i !=5) {
				
				System.out.println(i);
			}
		}

	}

}
