package PRUEBA_REPASO;

import java.util.Scanner;

public class If_repaso_4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner daymer = new Scanner(System.in);
		
//		4. Leer un número y decir si es par o impar.
		
		int numero = 0; 
		
		System.out.println("introduce un numero :");
		int num = daymer.nextInt();
		
		if( num % 2 == 0) {
			
			System.out.println("el numero es par ");
			
		}else {
			
			System.out.println("el nuemor es impar.");
		}
	}

}
