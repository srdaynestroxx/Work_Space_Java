package PRUEBA_REPASO;

import java.util.Scanner;

public class if_repaso_1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Scanner daymer = new Scanner(System.in);
		
//		1. Leer un número y decir si es aprobado o suspendido.
//		tmb se puede hacer con un int .
		
		int numero = 0;
		
		System.out.println("introduce un numero: ");
		int num = daymer.nextInt();
		
		if(num >= 5) {
			
			System.out.println("el numero que introduciste es aprobado !");
			
		}else if(num < 5){
			System.out.println("el numero que introduciste es un reprobado ;(");
		}
		

	}

}
