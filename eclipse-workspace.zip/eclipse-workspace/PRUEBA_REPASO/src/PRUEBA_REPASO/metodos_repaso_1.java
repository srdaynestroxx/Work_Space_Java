package PRUEBA_REPASO;

import java.util.Scanner;

public class metodos_repaso_1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		// Es necesario crear un método (procedimiento) que escriba en pantalla el
		// cambio entre diferentes monedas. Recibirá 3 parámetros:
		// double cantidad
		// char monedaIn: posibles valores: E, D, B -> euro, dolar, bitcoin
		// char modedaOut: posibles valores: E, D, B -> euro, dolar, bitcoin
		// Deberá realizar el cambio de monedaIn a monedaOut y escribir en
		// pantalla.	
		
		Scanner daymer = new Scanner(System.in);

        double cantidad;

        char monedaIn, monedaOut;

        // Tasas de cambio (aproximadas)
        double euroDolar = 0.85;       // 1 euro = 0.85 dólares
        double euroBitcoin = 0.000021; // 1 euro = 0.000021 BTC


        System.out.print("Introduce la cantidad: ");
        cantidad = daymer.nextDouble();


        System.out.print("Moneda de origen (E=Euro, D=Dólar, B=Bitcoin): ");
        monedaIn = daymer.next().charAt(0);


        System.out.print("Moneda de destino (E=Euro, D=Dólar, B=Bitcoin): ");
        monedaOut = daymer.next().charAt(0);


        double cantidadEnEuros = 0.0;
        double resultado = 0.0;
        
        // Convertir la moneda de entrada a euros

        switch (Character.toUpperCase(monedaIn)) {

            case 'E':
                cantidadEnEuros = cantidad;
                break;

            case 'D':
                cantidadEnEuros = cantidad / euroDolar;
                break;

            case 'B':
                cantidadEnEuros = cantidad / euroBitcoin;
                break;

            default:

                System.out.println("Moneda de origen no válida.");
                daymer.close();
                return;
        }


        // Convertir de euros a la moneda de salida

        switch (Character.toUpperCase(monedaOut)) {
            case 'E':
                resultado = cantidadEnEuros;
                break;

            case 'D':
                resultado = cantidadEnEuros * euroDolar;
                break;

            case 'B':
                resultado = cantidadEnEuros * euroBitcoin;
                break;

            default:
                System.out.println("Moneda de destino no válida.");

                daymer.close();
                return;

        }


        // Mostrar el resultado

        System.out.println(cantidad + " " + Character.toUpperCase(monedaIn) + " son " + resultado + " " + Character.toUpperCase(monedaOut));



        daymer.close();

    }

public static void dineroEuro(double euros) {
	//de euro a dolar 
	
	double dolares;
	double cambio = 1.16;
	dolares = euros * cambio;
	System.out.println(euros+" € = "+dolares+" $");	
	
}

}
