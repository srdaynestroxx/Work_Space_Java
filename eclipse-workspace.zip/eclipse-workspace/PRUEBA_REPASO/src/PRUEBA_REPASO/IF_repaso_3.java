package PRUEBA_REPASO;

import java.util.Scanner;

public class IF_repaso_3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Scanner daymer = new Scanner(System.in);

//		Leer un número y decir si es negativo, positivo o cero.
		
		int numero=0;
		
		System.out.println("introduce un numero :");
		int num = daymer.nextInt();
		
		if(num  > 0) {
			
			System.out.println("el numero introducido es positivo.");
			
		}else if(num == 0) {
			
			System.out.println("el numero introducido es cero.");
			
		}else if(num < 0) {
			
			System.out.println("el numero introducido es negativo");
			
		}
	}

}
