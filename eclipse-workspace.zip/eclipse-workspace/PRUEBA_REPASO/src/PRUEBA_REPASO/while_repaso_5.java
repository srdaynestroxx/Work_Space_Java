package PRUEBA_REPASO;

public class while_repaso_5 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

//escribe un programa en java que pida al usuario dos nuemros y muestre por pantalla todos los 
//numeros que hay emtre ellos( incluidos los numeros introducidps por el usuario).

	}

}
