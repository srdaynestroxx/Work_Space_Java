package PRUEBA_REPASO;

import java.util.Scanner; //import del scanner 

public class While_repaso_4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		// escribir un programa en java que pida al usuario numeros enteros hasta
		// que el numero introducido sea 0. cuando finalice, el programa debe decir
		// cuantos numeros pares
		// y cuantos impares ha introducido el usuario,cual es la suma de todos los
		// numeros introducidos y
		// cuantos numeros se han introducido ( el 0 no se tiene en cuenta ).

		Scanner daymer = new Scanner(System.in); // lector del scanner

		int numero = 0;//variable numero inicializada a cero.
		int contador =0;
		int sumaValores = 0;
		int par = 0;
		int impar = 0; 
		
		System.out.println("introduce numeros, si es cero el programa saldrá \n");

		System.out.println("Que numeros quieres poner ?");
		numero = daymer.nextInt();//se recoge un numero

		while (numero != 0) {
			
			contador++;
			sumaValores += numero;
			
			if(numero % 2 == 0) {
				par++;
				
			}else {
				impar++;
			}
			
			System.out.println("introduce mas numeros "); 
			numero = daymer.nextInt();
			
		}
			System.out.println("los numeros pares:"+par);
			System.out.println("los numeros impares:"+impar);
			System.out.println("la suma de los valores :"+sumaValores);
			System.out.println("la cantidad de valores es :"+contador);

			daymer.close();
	}
	
}
