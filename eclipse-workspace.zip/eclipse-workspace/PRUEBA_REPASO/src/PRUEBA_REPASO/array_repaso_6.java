package PRUEBA_REPASO;

import java.util.Scanner;

public class array_repaso_6 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner daymer = new Scanner(System.in);

//		  Definir el array de 5 elementos y rellenarlo de nombres. 
//		  Pedir un nombre al usuario e indicarle si está en el array  o no.

		String[] nombres = { "", "", "", "", "", ""};
		String lista;

		for (int i = 0; i < 5; i++) {

			System.out.print("Nombre " + (i + 1) + " : ");
			nombres[i] = daymer.nextLine();
		}

		for (int i = 0; i < nombres.length; i++) {
			System.out.println("los nombres en la lista son :"+nombres[i]); // sacar por pantalla los nombred metidos en el array

			daymer.close();
		}

	}
}
