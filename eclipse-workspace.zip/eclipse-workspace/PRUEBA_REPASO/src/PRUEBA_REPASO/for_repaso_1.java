package PRUEBA_REPASO;

public class for_repaso_1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

//		Escribir un programa que imprima los 10 primeros números
//		enteros empezando por el cero en orden ascendiente. (Utilizando for)
		
		
		int numero = 0;
		
		for(int i = 0; i<=10;i++) {
			
			System.out.println("los numeros van :"+i);
		}
	}

}
