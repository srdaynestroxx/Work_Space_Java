package PRUEBA_REPASO;

public class while_repaso_1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
//		Escribir un programa que imprima los 10 primeros números 
//		enteros empezando por el cero en orden ascendiente. (Utilizando while .)
		
		int numero = 0;
		
		
		while(numero <= 9) {
			
			numero++;
		System.out.println("los numeros van en orden :"+numero);
		}
	}
	

}
