package PRUEBA_REPASO;

public class arrays_repaso_5 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
//		Definir un array de 5 elementos y rellenarlo con los nombres. 
//		Luego, sacar de la pantalla los nombres que empiezan por A.
//		Se utilizará este este ejercicio para analizar el método startsWith de la clase String.
		
	 String[] nombre = {"Ana","Lorea","Unai","Ane","Pedro","Pepe"};
	 
	 
	 for(int i = 0; i < nombre.length ; i++) {
		 
		 
		 if (nombre[i].startsWith("A")) {
		System.out.println("los nombres por pantalla que inician con A son : " + nombre[i]);

			}	 
	 }
	
	}

}
