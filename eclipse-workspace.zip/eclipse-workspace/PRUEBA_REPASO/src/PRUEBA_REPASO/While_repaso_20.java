package PRUEBA_REPASO;

public class While_repaso_20 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		int numero1 = 0;
		int numero2 = 1;
		int numero3 = 0;
		
//		Visualizar los 10 primeros números de la serie Fibonacci (for)
		
		System.out.println(numero1);
		System.out.println(numero2);
		
	for(int i = 0; i<10 ;i++) {
		
		numero3 = numero1 + numero2;
		numero1 = numero2;
		numero2 = numero3;
		
		System.out.println(numero3);
		
		for (int i1 = 0; i1<10; i1++) {
			numero3 = numero1+ numero2;
			numero1 +=numero2;
			
		}
		
		System.out.println(numero1);
		
	}
	 }

}
