package PRUEBA_REPASO;

import java.util.Scanner;

public class metodod_repaso_2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Scanner daymer = new Scanner(System.in);

//			    Es necesario crear un método (función) llamado calcularAreaCirculo. Parámetros recibidos:
//				int diámetro y devolverá un double con el área. Utilizamos el ejercicio para ver
//				Math.PI y Math.Pow del import java.lang.Math;cómo y cómo limitar la visualización de posiciones decimales: 
//			   double valor = 123.456789;
//			    String.format("%.3f", valor)     
//			    Muestra: 123.456

				System.out.println("introduce el diamentro de l cirulo: ");
				int diametro = daymer.nextInt();
				
				double area = calcularAreaCirculo(diametro);
				
				System.out.println("El área del círculo es: " + String.format("%.3f", area));
		        daymer.close();
		                
	}
	public static double calcularAreaCirculo(int diamentro) {
		
		double radio = diamentro / 2.0;
		double area = Math.PI * Math.pow(radio, 2);
		return area ;
	}

}
