package PRUEBA_REPASO;

public class Basico_1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

				
//		contador dde 1-10 funcional 
		int personasCercanas = 10;
		int contador = 0;
		
		for(int i =0; i<personasCercanas; i++) {
			
			contador++;
			
			System.out.println(contador );

		}
	}

}
