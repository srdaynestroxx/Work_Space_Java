package PRUEBA_REPASO;

public class While_repaso_3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
//		Escribir un programa que imprima los 10 primeros números enteros 
//		empezando por el cero, excepto el 5. (Utilizando while).
		
		int numero = 0;
		
		while(numero <= 10) {
			
				if(numero !=5) {
					System.out.println("los numeros van :"+numero);
				}
				
				numero++;
		
		}
	}
}
