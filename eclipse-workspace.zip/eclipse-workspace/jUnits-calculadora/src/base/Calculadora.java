package base;

public class Calculadora {

	public static int sumar(int a, int b) {
		// TODO Auto-generated method stub
		
		
		return a + b;
	}

	public static int restar(int a, int b) {
		// TODO Auto-generated method stub
		return a - b;
	}

}
