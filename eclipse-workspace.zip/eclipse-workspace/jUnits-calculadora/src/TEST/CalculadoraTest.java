package TEST;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import base.Calculadora;

class CalculadoraTest {

	@Test
	void testSumar() {
		Calculadora calc = new Calculadora();
		int resultado = calc.sumar(2, 3); //si ejecutas este asi se supone que te va a dar todo bien sin errores,si ese 5 lo cambiarias por ej
		assertEquals(5,resultado);//por un 6 te aparecera 1 error de fallo xq el test no paso adecuadamente 
	}
	
	@Test
	void testRestar() {
		Calculadora calc = new Calculadora();
		int resultado = calc.restar(2, 3); //aqui por ejemplo me da 1 error xq 2-3 no es 0 si no 1 por lo tanto tendre 1 solo error marcado 
		assertEquals(0,resultado);
		
	}
	

}
