package OBJETOS;

import java.util.Arrays;

public class ANIMAL {
	
private	String nombre;
private String especie;
	private int edad;
private	String habitat[];
	
public ANIMAL(){
	
}

	public ANIMAL(String nombre,String especie, int edad,String habitat[]) {
		super();
		this.nombre=nombre;
		this.especie= especie;
		this.edad= edad;
		this.habitat=habitat;

	}
	
//	getters y setter 
	public String getNombre() {
	return nombre;
}

public void setNombre(String nombre) {
	this.nombre = nombre;
}

public String getEspecie() {
	return especie;
}

public void setEspecie(String especie) {
	this.especie = especie;
}

public int getEdad() {
	return edad;
}

public void setEdad(int edad) {
	this.edad = edad;
}

public String[] getHabitat() {
	return habitat;
}

public void setHabitat(String[] habitat) {
	this.habitat = habitat;
}

@Override
public String toString() {
return "Animal nombre=" + nombre + ", especie=" + especie + ", edad=" + edad + ", habitat="
		+ Arrays.toString(habitat) + "";
}

}