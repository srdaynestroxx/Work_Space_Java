package OBJETOS;

import java.io.*;
import java.util.*;

public class UsuariosMain {

	public static void main(String[] args) throws FileNotFoundException {
//		opciones para lo del menu 
		int opcion = 0;

		try {
//			constructores
//			PARA ALAMACENAR MIS OBJETOS DE USUARIOS
			ArrayList<Usuarios> ListaUsuarios = new ArrayList<>();
//			PARA METER COSAS POR PANTALLA 
			Scanner sc = new Scanner(System.in);
//			PARA LA RUTA DE MI ARCHIVO 
			File archivo = new File("src/OBJETOS/usuarios.csv");
//			PARA LEER EL ARCHIVO CON SCANNER 
			Scanner scanner = new Scanner(archivo);

			while (scanner.hasNextLine()) {
				// leer el fichero linea por linea
				String linea = scanner.nextLine();
				String[] columnas = linea.split(":");

				// Asigno cada parte a su variable correspondiente
				Usuarios usuario = new Usuarios();
				usuario.setId(Integer.parseInt(columnas[0]));
				usuario.setNombre(columnas[1]);
				usuario.setApellido(columnas[2]);
				usuario.setContraseina(columnas[3]);
				usuario.setActivo(columnas[4].equals("0") ? false : true);
				if (columnas.length == 5) {
					usuario.setNombreUsuario(columnas[1]);
				} else if (columnas.length == 6) {
					usuario.setNombreUsuario(columnas[5]);
				}
				ListaUsuarios.add(usuario);
			}
			scanner.close();
			
//			menu Principal del programa
			while(opcion!=6) {
				System.out.println("-----------------------");
				System.out.println("1-Mostrar un determinado usuario.");
				System.out.println("2-Mostrar todos los usuarios.");
				System.out.println("3-Borrar un determinado usuario.");
				System.out.println("4-Crear un usuario nuevo.");
				System.out.println("5-Crear un usuario con contraseina y activo por defecto");
				System.out.println("6-Editar los campos nombreUsuario y contraseina de un usuario existente.");
				System.out.println("7-Guardar los datos en el fichero (todos los campos).");
				System.out.println("Elige una opción: ");
				opcion = sc.nextInt();

				switch(opcion) {
				
				case 1:
					
					mostrarUsuarioDeterminado(ListaUsuarios);
					
					break;
					
				case 2: 
					
					mostrarTodosUsuarios(ListaUsuarios);
					
					break; 
					
				case 3:
					
					borrarUsuarios(ListaUsuarios);
					
					break;
					
				case 4:
					
					crearUsuarioNuevo(ListaUsuarios);
					
					break;
					
				case 5:
					
					CreaUsuarioContraseñaActivo(ListaUsuarios);
					
					break;
					
				case 6:
					
					EditarCamposUsuarioContraseña(ListaUsuarios);
				case 7:
					
						 System.out.println("la opcion elegida no es valida. . .");
				default:
					break;
				}
			}
			sc.close();

		} catch (FileNotFoundException e) {
			// Si no se encuentra el archivo salto esta excepción
						System.out.println("No se encontró el archivo.");
		}
	}


	private static void mostrarUsuarioDeterminado(ArrayList<Usuarios> listaUsuarios) {
		// TODO Auto-generated method stub
		Scanner lector1 = new Scanner(System.in);
		boolean existe = false;
		
		
		System.out.println("introduce el nombre del usuario a encontrar: ");
		String usuario = lector1.next();
		
		for(int i =0;i < listaUsuarios.size(); i++) {
			
			System.out.println(listaUsuarios.get(i));
			
		}
		
	}
	
	private static void mostrarTodosUsuarios(ArrayList<Usuarios> listaUsuarios) {
		// TODO Auto-generated method stub
		
		for(int i =0;i < listaUsuarios.size(); i++) {	
			System.out.println(listaUsuarios.get(i));
		}
	}
	
	private static void borrarUsuarios(ArrayList<Usuarios> listaUsuarios) {
		// TODO Auto-generated method stub
		
		
	}
	
	
	private static void crearUsuarioNuevo(ArrayList<Usuarios> listaUsuarios) {
		// TODO Auto-generated method stub
		
		
	}
	
	private static void CreaUsuarioContraseñaActivo(ArrayList<Usuarios> listaUsuarios) {
		// TODO Auto-generated method stub
		
		
	}
	
	private static void EditarCamposUsuarioContraseña(ArrayList<Usuarios> listaUsuarios) {
		// TODO Auto-generated method stub
		
		
		
	}

	private static void GuardarDatos(ArrayList<Usuarios> listaUsuarios) {
		// TODO Auto-generated method stub
		
		
		
	}







}
