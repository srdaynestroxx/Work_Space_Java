package OBJETOS;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;

public class auricularAPP {

	public static void main(String[] args) throws IOException {
		
		//main del proyecto de auriculares 
		//leer fichero con arraylist objetos
		
		
		Scanner sc = new Scanner (System.in);
		
		ArrayList<auricular> auricularList = new ArrayList<auricular>();
		int opcion = 100;
		boolean continuar = true;
		
		File file = new File("./src/OBJETOS/auriculares.csv");
		
		FileReader fr = new FileReader(file);
		BufferedReader br = new BufferedReader(fr);
		
		String linea = "";
		String[] campos;
		linea = br.readLine();
				
		while (linea != null) {
			auricular Auricular = new auricular();
			campos = linea.split(";");
			Auricular.setmodelo(campos[0]);
			Auricular.setmarca(campos[1]);
			Auricular.setprecio(Double.parseDouble(campos[2]));
			Auricular.setstock(Integer.parseInt(campos[3]));
			auricularList.add(Auricular);
			linea = br.readLine();
		}
		
		br.close();
		fr.close();
		
		do {
			
			System.out.println("Menu");
			System.out.println("1. Visualizar los elementos");
			System.out.println("2. Subir el precio");
			System.out.println("3. Añadir elementos");
			System.out.println("4. Guardar elementos");
			System.out.println("5. Salir");
			System.out.println("Elige una opcion.");
			opcion = sc.nextInt();
			
			switch (opcion) {
			
			case 1:
				visualizarElementos (auricularList);
				break;
				
			case 2:
				subirPrecio (auricularList);
				break;
				
			case 3:
				anadirElementos (sc, auricularList);
				break;
				
			case 4:
				guardarElementos (auricularList);
				break;
				
			case 5:
				System.out.println("Has salido del menu.");
				break;
				
			default:
				
			}
			
		} while (opcion != 5);
	}	
	
		private static void visualizarElementos (ArrayList<auricular> auricularList) {
			for (int i = 0; i < auricularList.size(); i++) {
			      System.out.println(auricularList.get(i).toString());
			    }
		}
		
		private static void subirPrecio (ArrayList<auricular> auricularList) {
			Scanner sc = new Scanner (System.in);
			
			String datoEntrada = "";
			boolean encontrado = false;
			
			System.out.println("Dime el nombre del auricular al que deseas incrementarle 10 euros el precio");
			datoEntrada = sc.nextLine();
			
			for (int i = 0; i < auricularList.size(); i++) {
			     if (auricularList.get(i).getmodelo().equalsIgnoreCase(datoEntrada)) {
			    	 auricularList.get(i).setprecio(auricularList.get(i).getprecio() + 10);
			    	 System.out.println("El precio se ha modificado correctamente");
			    	 encontrado = true;
			     }
			}
			
			if (encontrado == false) {
				System.out.println("Ese auricular no está en la lista.");
			}
		}
		
		private static void anadirElementos (Scanner sc, ArrayList<auricular> auricularList) {
			String datoEntrada = "";
			sc.nextLine();
			auricular auricularAux = new auricular();
			
			System.out.println("Introduce el modelo del nuevo auricular: ");
			datoEntrada = sc.nextLine();
			auricularAux.setmodelo(datoEntrada);
			
			System.out.println("Introduce la marca del nuevo auricular: ");
			datoEntrada = sc.nextLine();
			auricularAux.setmarca(datoEntrada);
			
			System.out.println("Introduce el precio del nuevo auricular: ");
			datoEntrada = sc.nextLine();
			auricularAux.setprecio(Double.parseDouble(datoEntrada));
			
			System.out.println("Introduce el stock del nuevo auricular: ");
			datoEntrada = sc.nextLine();
			auricularAux.setstock(Integer.parseInt(datoEntrada));
			auricularList.add(auricularAux);
			System.out.println("Se ha añadido el auricular correctamente.");
			System.out.println(auricularAux.toString());
		}
		
		private static void guardarElementos (ArrayList<auricular> auricularList) throws IOException {
			
			File file;
			file = new File("C:/VUESTRA RUTA/auriculares.txt");
			FileWriter fw = new FileWriter(file);
			BufferedWriter bw = new BufferedWriter(fw);
			
			for (int i = 0; i < auricularList.size(); i++) {
			     bw.write(auricularList.get(i).getmodelo() + ";" + auricularList.get(i).getmarca() + ";" + 
			    		 auricularList.get(i).getprecio() + ";" + auricularList.get(i).getstock() + "\n");
			    }
			System.out.println("Los datos han sido guardados.");
			
			bw.flush();
			bw.close();
		
	}

}
	//leer auricukares con datos puesto por nostor mismos ( forma corta ) 

		/*auricular auricular1 = new auricular ("Sony","WH-1000XM5",10.00,12);
		auricular auricular2 = new auricular();
		
		//ponemos los valores de nuestro metodo
		auricular2.setmarca("sony");					
		auricular2.setmodelo("WH-2302949482XMD");
		auricular2.setstock(16);
		auricular2.setprecio(15.00);		primera forma de leer el main 

		System.out.println(auricular1);
		System.out.println(auricular2);*/
		
		//segunda forma pero con ficheros
	