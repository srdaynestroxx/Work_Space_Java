package OBJETOS;

import java.util.*;


public class Alimento {
	
	private String nombre;
	private String estado;
	private double calorias;
	private double grasas;
	private double proteinas;
	private double carbohisdratos;
	private String tipo;


	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
