package OBJETOS;

public class persona {

		
		String nombre;
		private int edad;
		private String dni;
		//Pendiente hacer final el dni, tambien los metodos (no se pueden modificar(ovverriden)) y las clases pueden ser final(no se puede heredar)
		
		//CONSTRUCTOR , inicializa el objeto cuando se crea, no se devuelve nada y se llama como la clase
		public persona(){
			
		}
		
		public  persona (String nombre , int edad, String dni) {
			this.dni = dni;
			this.nombre = nombre;
			this.edad = edad;
		}
		
		//GETTER Y SETTERS
		//Mediante el public hacemos que sea accesible para clases dentro del mismo sistema
		//Si no se indica nada, por defecto solo acceesible para clases dentro del mismo paquete
		//Private, solo accesible dentro de la misma clase
		//protected, solo accesible para clases dentro del mismo paquete y subclases(lo veremos en herencia)
		
		String getNombre() {
			return nombre;
		}
		
		public void setNombre(String nombre) {
			this.nombre = nombre;
		}
		
		public String getDni() {
			return dni;
		}
		
		public void setDni(String dni) {
			this.dni = dni;
		}
		
		public int getEdad() {
			return edad;
		}
		
		public void setEdad(int edad) {
			this.edad = edad;
		}
		
		public void mostrarDatos() {
			System.out.println("NOMBRE= "+nombre);
			System.out.println("DNI= "+dni);
			System.out.println("EDAD= "+edad);
		}
		
		//static= puede ser accedido sin necesidad de crear un objeto de la clase.
		static void miMetodoStatic() {
			System.out.println("No necesito un objeto para imprimir esta linea");
		}
		
		public static void main (String[]args) {
			
			//CREAMOS UNA PERSONA MEDIANTE NUESTRA PLANTILLA
			persona persona2 = new persona ("Jose",25, "123A");
			
			persona2.mostrarDatos();
			
			System.out.println("\n \n");
			
			System.out.println(persona2.getNombre());
			System.out.println(persona2.getDni());
			System.out.println(persona2.getEdad());
			System.out.println(persona2.nombre);
			
			System.out.println("\n \n");
			
			//MODIFICAMOS A LA PERSONA QUE HEMOS CREADO
			persona2.setNombre("Carlos");
			persona2.setDni("789C");
			persona2.setEdad(35);
			
			persona2.mostrarDatos();
		}
		
	}
