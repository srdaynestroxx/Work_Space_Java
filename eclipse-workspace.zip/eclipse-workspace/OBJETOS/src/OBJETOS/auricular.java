package OBJETOS;

public class  auricular{
	
	//atributos
	private String modelo;
	private String marca;
	private double precio;
	private int stock;

	//constructor 
public  auricular() {
	
	
}

public auricular(String modelo, String marca, double precio, int stock) {
	super();
	this.modelo = modelo;
	this.marca = marca;
	this.precio = precio;
	this.stock = stock;
}

//getter y setter
public String getmodelo() {
	return modelo;
}

public void setmodelo(String modelo) {
	this.modelo = modelo;
}

public String getmarca() {
	return marca;
}

public void setmarca(String marca) {
	this.marca = marca;
}

public double getprecio() {
	return precio;
}

public void setprecio(double precio) {
	this.precio = precio;
}

public int getstock() {
	return stock;
}

public void setstock(int stock) {
	this.stock = stock;
}

/*metodo
public void mostrarDatos() {
	
	System.out.println("modelo = "+modelo);
	System.out.println("marca = "+marca);
	System.out.println("precio = "+precio);
	System.out.println("Stock = "+stock);

}*/


//generate to string 
@Override
public String toString() {
	return "auriculares1 modelo=" + modelo + ", marca=" + marca + ", precio=" + precio + ", stock=" + stock + "";
	
}

	
}
