package OBJETOS;

import java.util.*;
import java.io.*;

public class Usuarios {

	private int id;
	private String nombre;
	private String apellido;
	private String nombreUsuario;
	private String contraseina;
	private boolean activo =false;

public Usuarios() {
	
	
}

public Usuarios(int id, String nombre,String apellido,String nombreUsuario,String contraseina,boolean activo) {

	super();
	
	this.id=id;
	this.nombre=nombre;
	this.apellido=apellido;
	this.nombreUsuario=nombreUsuario;
	this.contraseina=contraseina;
	this.activo=activo;	
}

//getter y setter 
public int getId() {
	return id;
}

public void setId(int id) {
	this.id = id;
}

public String getNombre() {
	return nombre;
}

public void setNombre(String nombre) {
	this.nombre = nombre;
}

public String getApellido() {
	return apellido;
}

public void setApellido(String apellido) {
	this.apellido = apellido;
}

public String getNombreUsuario() {
	return nombreUsuario;
}

public void setNombreUsuario(String nombreUsuario) {
	this.nombreUsuario = nombreUsuario;
}

public String getContraseina() {
	return contraseina;
}

public void setContraseina(String contraseina) {
	this.contraseina = contraseina;
}

public boolean isActivo() {
	return activo;
}

public void setActivo(boolean activo) {
	this.activo = activo;
}

public Usuarios(int id, String nombre,String apellido) {
	this.id=id;
	this.nombre=nombre;
	this.apellido=apellido;
	this.nombreUsuario=nombre;
	this.contraseina="1234";
	this.activo=true;	
	
}


@Override
public String toString() {
	return "Usuarios id=" + id + ", nombre=" + nombre + ", apellido=" + apellido + ", nombreUsuario="
			+ nombreUsuario + ", contraseina=" + contraseina + ", activo=" + activo + "";
}
}