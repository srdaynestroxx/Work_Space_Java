package OBJETOS;

public class main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		//CREAMOS UNA PERSONA MEDIANTE NUESTRA PLANTILLA
		persona persona1 = new persona ("Jose", 25, "123A");
		
		persona1.mostrarDatos();
		
		System.out.println("\n \n");
		
		System.out.println(persona1.getNombre());
		System.out.println(persona1.getDni());
		System.out.println(persona1.getEdad());
		
		System.out.println("\n \n");
		
		//MODIFICAMOS A LA PERSONA QUE HEMOS CREADO
		persona1.setNombre("Josefina");
		persona1.setDni("456B");
		persona1.setEdad(28);
		
		persona1.mostrarDatos();
		
	}
	

	}


