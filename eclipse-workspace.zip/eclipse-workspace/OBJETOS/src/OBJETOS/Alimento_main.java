package OBJETOS;

public class Alimento_main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
