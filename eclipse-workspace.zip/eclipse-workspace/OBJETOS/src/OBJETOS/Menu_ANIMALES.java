package OBJETOS;

import java.io.*;
import java.util.*;

public class Menu_ANIMALES {

	public static void main(String[] args) throws FileNotFoundException {

		int opcion = 0;

		try {
			// Lista donde voy a guardar todos los animales que leo del CSV
			ArrayList<ANIMAL> listaAnimales = new ArrayList<>();
			Scanner lector = new Scanner(System.in);

			// Archivo CSV donde están los animales
			File archivo = new File("src/OBJETOS/info.csv");
			Scanner scanner = new Scanner(archivo);

			// Leo el archivo CSV línea por línea
			while (scanner.hasNextLine()) {
				String linea = scanner.nextLine();

				// Divido la línea usando :: como separador
				String[] columnas = linea.split("::");

				// Asigno cada parte a su variable correspondiente
				String nombre = columnas[0];
				String especie = columnas[1];
				int edad = Integer.parseInt(columnas[2]);

				// En el fichero cada hábitat va separado por :: también
				String[] habitats = { columnas[3], columnas[4], columnas[5] };

				// Creo el objeto Animal con los datos obtenidos
				ANIMAL a = new ANIMAL(nombre, especie, edad, habitats);

				// Lo añado al ArrayList
				listaAnimales.add(a);
			}
			
scanner.close();

			// Menú principal del programa
			while (opcion != 4) {

				System.out.println("\n--- MENÚ PRINCIPAL ---");
				System.out.println("1. Visualizar los datos de 2 animales.");
				System.out.println("2. Visualizar el animal más longevo.");
				System.out.println("3. Visualizar los habitats del animal que decida el usuario.");
				System.out.println("4. Salir");
				System.out.print("Elige una opción: ");

				opcion = lector.nextInt();

				switch (opcion) {

				case 1:
					// Muestro los dos primeros animales de la lista
					visualizarDosAnimales(listaAnimales);
					break;

				case 2:
					// Busco y muestro el animal con mayor edad
					animalMasLongevo(listaAnimales);
					break;

				case 3:
					// Muestro los hábitats según el nombre que ponga el usuario
					mostrarHabitats(listaAnimales, lector);
					break;

				case 4:
					System.out.println("Saliendo...");
					break;

				default:
					System.out.println("Opción no válida.");
				}
			}

			lector.close();

		} catch (FileNotFoundException e) {
			// Si no se encuentra el archivo salto esta excepción
			System.out.println("No se encontró el archivo.");
		}

	}

	// Muestra únicamente los dos primeros animales cargados
	public static void visualizarDosAnimales(ArrayList<ANIMAL> lista) {
		for (int i = 0; i < 2 && i < lista.size(); i++) {
			System.out.println(lista.get(i));
		}
	}

	// Busca dentro de la lista qué animal tiene mayor edad
	private static void animalMasLongevo(ArrayList<ANIMAL> lista) {

		// De momento el "mayor" será el primero de la lista
		ANIMAL mayor = lista.get(0);

		// Recorro todos los animales
		for (ANIMAL a : lista) {

			// Si encuentro uno con más edad lo guardo como nuevo "mayor"
			if (a.getEdad() > mayor.getEdad()) {
				mayor = a;
			}
		}

		// Muestro el animal con más edad
		System.out.println("Animal más longevo:");
		System.out.println(mayor);
	}

	// Busca un animal por nombre y muestra sus hábitats
	private static void mostrarHabitats(ArrayList<ANIMAL> lista, Scanner lector) {

		lector.nextLine(); // Limpia el buffer del Scanner

		System.out.print("Introduce el nombre del animal: ");
		String nombre = lector.nextLine();

		// Recorro todos los animales buscando el que coincida con el nombre
		for (ANIMAL a : lista) {

			if (a.getNombre().equalsIgnoreCase(nombre)) {
				System.out.println("Hábitats de " + nombre + ":");
				System.out.println(Arrays.toString(a.getHabitat()));
				return; // Termino el método cuando lo encuentro
			}
		}

		// Si llega aquí es que no se encontró el animal
		System.out.println("No existe un animal con ese nombre.");
	}

}