package CC;

import java.util.*;

 final public class CuentaPlazo extends CuentaCorriente {
	
	private String RegistroFecha;
	
	CuentaPlazo(String iban,String RegistroFecha ) {
		super(iban, 0);
		this.RegistroFecha=RegistroFecha;

	}
	public CuentaPlazo() {
		super();
		setPortcentajeComision(0);
	}
	
	public String getRegistroFecha() {
		return ;
	}
	
	