package CC;

public class CuentaCorriente {

	    public String iban;
	    private float saldo;
	    private int ingresoCuenta;
	    private float porcentajeComision;
	    

	CuentaCorriente () {
	    this.iban = iban; 
	    this.saldo =0;
	    this.porcentajeComision = porcentajeComision;
	    this.ingresoCuenta = 0;
	}    
	public void setPorcentajeComision (float porcentajeComision) {
	    this.porcentajeComision = porcentajeComision;
	}
	public float getPorcentajeComision () {
		return porcentajeComision;
		}
	public float getsaldo (){
		
		return (saldo);
		}
	
	public void setsaldo(float saldo) {
		
		this.saldo=saldo;
		
	}
	public int getIngresoCuenta() {
		
		return ingresoCuenta;
		
	}
	public void setIngresoCuenta(int ingresoCuenta) {
		
		this.ingresoCuenta = ingresoCuenta;
		
	}
	public void ingresarDinero (float cantidad) {
	    float bonus=0;
	    if (++ingresoCuenta == 3) {
	    	ingresoCuenta = 0; 
	       bonus =0.7f;
	    }    
	    saldo += cantidad + bonus;
	}

	public boolean sacarDinero (float cantidad) {
	    float comision = porcentajeComision * cantidad;
	    if (cantidad + comision <= saldo) {
	       saldo -= cantidad+comision;  //resta (importe+comision)
	       ingresoCuenta = 0;
	       return true;
	    }
	    else return false; 
	}
	} // fin clase