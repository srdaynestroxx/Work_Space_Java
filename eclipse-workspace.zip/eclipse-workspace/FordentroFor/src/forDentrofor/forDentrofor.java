package forDentrofor;

import java.util.Scanner;

public class forDentrofor {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
        // Outer loop: controls the number of rows

        for (int i = 0; i < 5; i++) {

            // Inner loop: controls the number of columns

            for (int j = 0; j <= i; j++) {

                System.out.print("* ");

            }

            // Move to the next line after inner loop completes

            System.out.println();

        }

    }

	}
