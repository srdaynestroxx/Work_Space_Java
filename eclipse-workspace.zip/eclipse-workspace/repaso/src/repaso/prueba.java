package repaso;

public class prueba {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		 double raizCuadrada = Math.sqrt(25.0); // No necesita importación
	        System.out.println("La raíz cuadrada es: " + raizCuadrada);

	        double pi = Math.PI; // La constante PI se accede directamente
	        System.out.println("El valor de PI es: " + pi);
	    }
	}