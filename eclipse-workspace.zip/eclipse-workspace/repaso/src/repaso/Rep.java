package repaso;

import java.io.*;//importo todo del io y todo del scanner
import java.util.*;

public class Rep {

	public static void main(String[] args)throws IOException {//captura directamente el error aqui en vez del try catch
		
		Scanner scanner = new Scanner(System.in);//contaodr para la entrada de datos por pantalla 
		int opcion =0;//contador de mis opciones en el do while 
		String linea=null;
		String campos[];
		
		String arrayNombre[]=new String[20];//declaramos los valores en array del contenido del archivo ( ponemos 20 xq hay 20  nombres 9)
		String arrayTipo[]= new String[20];//lo mismo aqui, hay 20 tipos
		int arrayNivel[]= new int[20];//etc
		int arrayAtaque[]= new int[20];//etccc
		int arrayDefensa[]= new int[20];
		int arrayVelocidad[]= new int[20];
		
		File file = new File("C:\\Users\\1AWA-18\\Desktop\\tareas\\PROGRAM\\java\\ficheros\\pokemons.csv");
		Scanner daymer = new Scanner(file);//scanner para el archivo
		FileReader fr = new FileReader(file);
		BufferedReader br = new BufferedReader(fr);
		
		br.readLine();//lee las lineas del fichero
		linea=br.readLine();//se salta el encabezado. . . 
		
		while(linea!= null) {//mientras que las lineas no esten vacias las va a leer
			System.out.println(linea);//imprime las lineas leidas.
			linea = br.readLine();//se salta la linea del encabezao
		}
		
		br.close();//cierro el buffer
		fr.close();//cierro el file 
		
		if(daymer.hasNextLine()) 
			daymer.nextLine();
		
		int i =0;//contador de las opciones 
		while(daymer.hasNext()) {
			linea = daymer.nextLine();
			campos= linea.split(",");//separa los elementos con coma 
			
			arrayNombre[i] = campos[0];//la primera posicion del array es 0 
			arrayTipo[i]= campos [1];//lo mismo aqui, hay 20 tipos
			arrayNivel[i]=Integer.parseInt(campos[2]);//convierte los valores en int 
			 arrayAtaque[i]= Integer.parseInt(campos[4]);//etc
			 arrayDefensa[i]= Integer.parseInt(campos[5]);//etc. . .
			 arrayVelocidad[i]= Integer.parseInt(campos[6]);
		}
		
		
	}
}
