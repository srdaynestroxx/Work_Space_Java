package repaso;

import java.util.Scanner; //import del scanner 

public class IF2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		Scanner daymer = new Scanner(System.in); //lector del scanner para escribir en la consola 
		
//		 Pedir el usuario y la contraseña y decir si el login está bien. (usuario: ikaslea
//		 contraseña: ik1920)
		
		String UsuarioCorrecto = "ikaslea";
		String contraseñaCorrecta = "ik1920"; //variables 
		
		System.out.println("introduce tu usuario :");
		String usuario = daymer.next();
		
		if(usuario.contains(UsuarioCorrecto)) { //para comparar Strings es mejor usar el contains 
			System.out.println("usuario introducido con exito.");
		}else {
			System.out.println("usuario incorecto,intentelo de nuevo.");
			
			return;
		}
		System.out.println("introduce tu contraseña: ");
		String contraseña = daymer.next();
		
		if(contraseña.contains(contraseñaCorrecta)) {
			
			System.out.println("contraseña introducida con exito.");
			
		}else {
			System.out.println("contraseña incorrecta.");
		}
		daymer.close();
	}

}
