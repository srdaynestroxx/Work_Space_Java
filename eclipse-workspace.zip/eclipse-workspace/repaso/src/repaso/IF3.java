package repaso;

import java.util.Scanner; //import del scanner 

public class IF3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		Scanner daymer = new Scanner(System.in); //lector del scanner para escribir en la consola 
		
//		Pedir tres números, una mayor que otra, si el usuario introduce menor o igual
//		visualizar mensaje de ERROR.
	
		int numero1 = 0;
		int numero2 = 0;
		int numero3 = 0;
		
		System.out.println("introduce un numero");
		int numero = daymer.nextInt();
		
		if(numero1 == numero1) {
			System.out.println("error, el numero es igual.");
		}else if(numero1 > numero2) {
			
			System.out.println("el numero mayor es :"+numero1);
		}else {
			System.out.println("el"+numero2+" es mayor que el"+numero1);
		} 
		
	}

}
