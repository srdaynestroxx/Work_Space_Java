package repaso; 

import java.util.Scanner; 

public class repaso {

public static void main (String[] args) {
	
	Scanner daymer = new Scanner(System.in);
	
//	Desarrolla un programa en Java que cumpla los siguientes requisitos:
//		Pide al usuario por teclado cuántos alumnos va a registrar.
//		Para cada alumno, pide nombre, edad y población.
//		Muestra en pantalla la información introducida de cada alumno.
//		Imprime el nombre y la edad del alumno mayor (el primero, si hay empate).
//		Calcula y muestra la edad media de la clase.
//		Solicita una población y muestra cuántos alumnos proceden de esa población.
//		Muestra sin repetir las poblaciones donde hay alumnos - Dificil (2p)
//		Muestra cuántos alumnos hay en cada una de las poblaciones. - Dificil (2p)
//		Utiliza exclusivamente arrays y la clase Scanner para la entrada de datos. No se permite el uso de ArrayList, Set o Map.	
	
		String[] nombres = {""};
		int[] numeroPersonas = new int [10];
		int contador = 0;
		int opcion;
		System.out.println("ingresa el numero de personas :");
		contador = daymer.nextInt();
		
		System.out.println("elige una opcion :");
		do {
			
			System.out.println("Pide al usuario por teclado cuántos alumnos va a registrar");
			System.out.println("Para cada alumno, pide nombre, edad y población.");
			System.out.println("Muestra en pantalla la información introducida de cada alumno.");
			System.out.println("Imprime el nombre y la edad del alumno mayor (el primero, si hay empate).");
			System.out.println("Calcula y muestra la edad media de la clase.");
			System.out.println("Solicita una población y muestra cuántos alumnos proceden de esa población.");
			System.out.println("Muestra sin repetir las poblaciones donde hay alumnos - Dificil (2p)");
			System.out.println("Muestra cuántos alumnos hay en cada una de las poblaciones. - Dificil (2p)");
			System.out.println("Utiliza exclusivamente arrays y la clase Scanner para la entrada de datos. No se permite el uso de ArrayList, Set o Map.");

			
		}while(opcion!=9);
		for(int i =0; i <numeroPersonas.length; i++)
		if(numeroPersonas.equals(numeroPersonas[i])) {
			
			
			
			
		}
					
		System.out.println("el numero de personas que haz introducido es :"+contador);
				
		if(contador > 10) {
			
			System.out.println("el numero de personas que intentas introducir es demasiado grande, intentalo de nuevo ");
			
		}
		
		

	
	
	System.out.println("dame un nombre de persona :");
	daymer.next();
	
	for(int i = 0; i<nombres.length; i++) {
		if(nombres.equals(nombres[i])) {
			System.out.println();
		}
		
	

    // 2. Declarar los arrays de nombres, edades y poblaciones
    // ... (COMPLETAR)

    // 3. Recoger los datos de cada alumno en los arrays
        // Pide nombre, edad y población e inserta en los arrays
        // ... (COMPLETAR)
    }

    // 4. Mostrar los datos de cada alumno
    // ... (COMPLETAR)

    // 5. Encontrar el alumno con mayor edad
    // ... (COMPLETAR)

    // 6. Calcular la edad media
    // ... (COMPLETAR)

    // 7. Solicitar una población y mostrar el número de alumnos de esa población
    // ... (COMPLETAR)

    // 8. Listar poblaciones sin repetir y contar alumnos por población
    // ... (COMPLETAR)	

}
}