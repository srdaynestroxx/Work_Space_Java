package repaso;

import java.util.Scanner; //import del scanner 

public class IF4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		Scanner daymer = new Scanner(System.in); //lector del scanner para escribir en la consola 
		
//		 Pedir un número y decir que nota le corresponde.
//		 ○ Entre 1 y 4,9: suspenso
//		 ○ Entre 5 y 5,9: suficiente
//		 ○ Entre 6 y 6,9: bien
//		 ○ Entre 7 y 8,9: muy bien
//		 ○ Entre 9 y 10: sobresaliente
//		 ○ Si no ERROR.
	
		int numero1 = 0;
		int numero2 = 0;
		int numero3 = 0;
		
		System.out.println("introduce un numero");
		int numero = daymer.nextInt();
		
		if(numero1 == numero1) {
			System.out.println("error, el numero es igual.");
		}else if(numero1 > numero2) {
			
			System.out.println("el numero mayor es :"+numero1);
		}else {
			System.out.println("el"+numero2+" es mayor que el"+numero1);
		} 
		
	}

}
