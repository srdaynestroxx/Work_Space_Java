package logs_properties;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.logging.LogManager;
import java.util.logging.Logger;

public class MainProperties {
        public static void main(String[] args) {
            try (FileInputStream fis = new FileInputStream("config/logging.properties")){
                LogManager.getLogManager().readConfiguration(fis);
            }catch(IOException e){
                System.err.println("No se pudo cargar logging.properties: "+e.getMessage());
            }
            
            Logger logger = Logger.getLogger(MainProperties.class.getName());
            
            calculator calc = new calculator();
            
            logger.info("Realizando suma 3 + 4");
            double r1 = calc.add(3, 4);
            logger.info("La suma de los dos numero es de: "+r1);
            
            logger.info("Realizando resta 7 - 2");
            double r2 = calc.sub(7, 2);
            logger.info("La resta de los numeros es de: "+r2);
            
            logger.info("Realizando multiplicacion 5 * 2");
            double r3 = calc.mul(5, 2);
            logger.info("La multiplicacion de los numeros es de: "+r3);
            
            logger.info("Realizando division 10 / 2");
            
            try {
                double r4 = calc.div(10, 2);
                logger.info("La division de los dos numeros es de: "+r4);
            }catch(ArithmeticException e){
                logger.info("Error en dividion: "+e.getMessage());
            }
            
            logger.info("Fin del programa basico");
            
            
        }
}