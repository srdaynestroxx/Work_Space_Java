package Examen1;

import java.util.Scanner; //para leer por pantalla 
import java.util.Arrays;	//uso de arrays

public class Examen1 {


	public static void main(String[] args) {
		// TODO Auto-generated method stub

//		Se preguntará por pantalla cuántos trabajadores hay en la empresa.
//		Los nombres de esos trabajadores, sus edades y sus oficios se guardarán en 3 arrays 
//		(es necesario pedir los datos por pantalla).
		
		Scanner daymer = new Scanner(System.in);
		
		int[] antiguedad = {}; 
		String[] oficios = {""};	//variables 
		String[]nombres = {""};
		
		int trabajadores = 0; //numero de trabajadores que aumentará 
		
		System.out.println("¿ cuantos trabajadores hay en la empresa ?"); //se pregunta cuantos trabajadores hay ?
		trabajadores = daymer.nextInt();
		
		System.out.println("introduce el nombre: ");
		String GuardaNombres = daymer.next();
		
		for(int i = 0; i<nombres.length; i++) {
			if(GuardaNombres.equalsIgnoreCase(nombres[i])) ;
				
			
		}
		
		System.out.println("introduzca su antiguedad : ");
		int GuardaAntiguedades = daymer.nextInt(); 
			

		System.out.println("introduzca el oficio: ");
		
		
			System.out.println("los datos del trabajador/a son: "+GuardaNombres+ "-" +GuardaAntiguedades);
	}
	}
