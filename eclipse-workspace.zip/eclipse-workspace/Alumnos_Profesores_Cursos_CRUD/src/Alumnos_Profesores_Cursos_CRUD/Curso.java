package Alumnos_Profesores_Cursos_CRUD;

public class Curso {

	private String titulo;
	private String 
}
