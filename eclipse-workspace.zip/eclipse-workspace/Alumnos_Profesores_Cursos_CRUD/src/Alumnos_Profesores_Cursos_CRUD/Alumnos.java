package Alumnos_Profesores_Cursos_CRUD;

import java.util.ArrayList;
import java.util.Arrays;

public class Alumnos {
//definicion de variables
	private String nombre;
	private int edad;
	private String[] cursos;

	// constructor sin parametros
	public Alumnos() {

		this.cursos=new String[0];

	}

//constructor con paramentros
	public Alumnos(String nombre, int edad) {

		super();
		this.nombre = nombre;
		this.edad = edad;
		this.cursos=new String[0];

	}

//getters y setters
	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public int getEdad() {
		return edad;
	}

	public void setEdad(int edad) {
		this.edad = edad;
	}

	public String[] getCursos() {
		return cursos;
	}

	public void anyadirCurso(String [] cursos) {

	
}
}