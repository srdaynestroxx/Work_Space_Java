package logs_simples;

import java.util.logging.ConsoleHandler;
import java.util.logging.Level;
import java.util.logging.Logger;

public class MainLoggerBasic {
	
 // Obtener el Logger raíz (o un logger sin nombre específico)
        // Usamos Logger.getLogger("") que es el logger global/raíz
   private static final  Logger logger = Logger.getLogger(calculator.class.getName()); 

    public static void main(String[] args) {
        // 1. Crear y configurar el logger directamente en el main

       
        // Desactivar useParentHandlers para evitar que los mensajes 
        // se muestren dos veces si el logger raíz ya tiene un handler por defecto.
        logger.setUseParentHandlers(false);

        // Crear y añadir un ConsoleHandler
        ConsoleHandler handler = new ConsoleHandler();
        
        // Establecer el nivel de log para el Logger (INFO)
        logger.setLevel(Level.INFO); 

        // También establecemos el nivel para el Handler, 
        // de lo contrario podría seguir usando el nivel por defecto (Level.INFO)
        handler.setLevel(Level.INFO); 
        
        logger.addHandler(handler);
        
        
        // Lógica de la aplicación
        calculator calculator = new calculator();
        double num1 = 10.0;
        double num2 = 5.0;
        double result;

        // --- Operación de Suma (add) ---
        logger.info("Iniciando operación: Suma"); // 2. Registrar mensaje antes
        result = calculator.add(num1, num2);
        logger.info("Resultado de la suma: " + result); // 2. Registrar mensaje después

        // --- Operación de Resta (sub) ---
        logger.info("Iniciando operación: Resta");
        result = calculator.sub(num1, num2);
        logger.info("Resultado de la resta: " + result);

        // --- Operación de Multiplicación (mul) ---
        logger.info("Iniciando operación: Multiplicación");
        result = calculator.mul(num1, num2);
        logger.info("Resultado de la multiplicación: " + result);

        // --- Operación de División (div) - Caso Exitoso ---
        logger.info("Iniciando operación: División (" + num1 + " / " + num2 + ")");
        try {
            result = calculator.div(num1, num2);
            logger.info("Resultado de la división: " + result);
        } catch (ArithmeticException e) {
            // Este catch no se ejecutará, pero está aquí para consistencia.
            logger.log(Level.SEVERE, "Excepción en división: " + e.getMessage());
        }

        // --- Operación de División (div) - Caso de División por Cero ---
        double num3 = 0.0;
        logger.info("Iniciando operación: División (" + num1 + " / " + num3 + ")");

        // 3. Manejar la excepción de división por cero
        try {
            result = calculator.div(num1, num3);
            logger.info("Resultado de la división: " + result);
        } catch (ArithmeticException e) {
            // Registrar un mensaje SEVERE en caso de error
            logger.log(Level.SEVERE, "Error detectado: " + e.getMessage()); 
        }
    }
}