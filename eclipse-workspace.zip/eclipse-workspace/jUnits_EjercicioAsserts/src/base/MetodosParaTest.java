package base;

public class MetodosParaTest {

    // Para assertEquals y assertNotEquals
    public int sumar(int a, int b) {
        return a + b;
    }

    // Para assertTrue y assertFalse
    public boolean esMayorDeEdad(int edad) {
        return edad >= 18;
    }

    // Para assertNull y assertNotNull
    public String obtenerUsuario(boolean existe) {
        if (existe) {
            return "admin";
        } else {
            return null;
        }
    }

    // Para assertArrayEquals
    public int[] primerosTresNumeros() {
        return new int[]{1, 2, 3};
    }

    // Para assertThrows y assertDoesNotThrow
    public int dividir(int a, int b) {
        if (b == 0) {
            throw new IllegalArgumentException("No se puede dividir entre cero");
        }
        return a / b;
    }

    // Para assertDoesNotThrow
    public void metodoSeguro() {
        // No hace nada, nunca lanza excepción
    }
}