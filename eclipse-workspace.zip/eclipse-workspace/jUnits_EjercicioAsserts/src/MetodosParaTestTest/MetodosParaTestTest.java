package MetodosParaTestTest;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;
import base.MetodosParaTest;

public class MetodosParaTestTest {

	@Test
	void testSumar() {
		// Instanciar mi clase
		MetodosParaTest mpt = new MetodosParaTest();

		// Ejecuto el método y guardar el resultado
		int resultado = mpt.sumar(2, 3);

		// Realizo wl asssert
		assertEquals(5, resultado); // el resultado sera 5 porque 2+3 es 5
	}

	@Test
	void testSumarNotEquals() {
		// instancio mi clase
		MetodosParaTest mpt = new MetodosParaTest();

		// ejecutop mi metodo y guardo el resultado
		int resultado = mpt.sumar(2, 3);

		// realizo el assert
		assertNotEquals(6, resultado); // el resultado no sera 6 xq 2+3 no es 6
	}

	@Test
	void testEsMayorEdad() {
		// instancio mi calse
		MetodosParaTest mpt = new MetodosParaTest();

		// ejecuot mi mwtodo y guardo mi resultado
		boolean esMayorDeEdad = mpt.esMayorDeEdad(18);

		// La prueba pasará si estaLogueado es true
		assertTrue(esMayorDeEdad, "El usuario cumple con la edad requerida para ser mayor de edad");

	}

	@Test
	void testNoEsMayorEdad() {
		
		// instancio mi calse
		MetodosParaTest mpt = new MetodosParaTest();

		// ejecuot mi metodo y guardo mi resultado
		boolean esMayorDeEdad = mpt.esMayorDeEdad(17);

		// La prueba pasará si el usuario es menor a 18 es false
		assertFalse(esMayorDeEdad, "El usuario de momento NO cumple con la edad requerida para ser mayor de edad");

	}

	@Test
	void testNullobtenerUsuario() {
		
		//instancio mi clase 
		MetodosParaTest mpt = new MetodosParaTest();
		
		//ejecuto mi metodo y guardo mi resdultado
		String usuario = mpt.obtenerUsuario(false);
		
		//laprueba pasara si el usuario es null
		assertNull(usuario, "El usuario no existe en la base de datos");
		
	}
	
	@Test
	void testNotNullobtenerUsuario() {
		// intancio mi clase
		MetodosParaTest mpt = new MetodosParaTest();
		
		//ejecuto mi metodo y guardo mi resultado
		String usuario = mpt.obtenerUsuario(true);
		// La prueba pasará si usuario NO es null
		assertNotNull(usuario, "El usuario existe en la base de datos");
	}
	
	@Test
	void testPrimerosTresNumeros() {
		// instancio mi clase
		MetodosParaTest mpt = new MetodosParaTest();
		
		// ejecuto mi metodo y guardo mi resultado
		int[] resultado = mpt.primerosTresNumeros();
		
		// defino el array esperado
		int[] esperado = {1, 2, 3};
		
		// La prueba pasará si los dos arrays son iguales
		assertArrayEquals(esperado, resultado, "Los arrays deben ser idénticos");
	}

	@Test
	void testDividirException() {
		// instancio mi clase
		MetodosParaTest mpt = new MetodosParaTest();
		
		// La prueba pasará si el método lanza IllegalArgumentException al dividir por cero
		assertThrows(IllegalArgumentException.class, () -> {
			mpt.dividir(10, 0);
		}, " lanza IllegalArgumentException al dividir por cero (no se puede dividir por cero )");
		
		}

	@Test
	void testDividirSinException() {
		// instancio mi clase
		MetodosParaTest mpt = new MetodosParaTest();
		
		// La prueba pasará si el método NO lanza ninguna excepción con valores válidos

		assertDoesNotThrow(() -> {
			mpt.dividir(10, 2);
		}, "No lanza ninguna excepción al dividir por ( un número distinto de cero )");
		}

	@Test
	void testMetodoSeguroSinException() {
		// instancio mi clase
		MetodosParaTest mpt = new MetodosParaTest();
		
		// La prueba pasará si el método seguro se ejecuta sin errores
		assertDoesNotThrow(() -> {
			mpt.metodoSeguro();
		}, "El método seguro no debería lanzar ninguna excepción");
	}
}
