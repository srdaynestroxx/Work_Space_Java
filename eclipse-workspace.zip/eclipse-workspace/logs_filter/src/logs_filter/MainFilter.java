package logs_filter;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.logging.*;

public class MainFilter {
    public static void main(String[] args) {
        try (FileInputStream fis = new FileInputStream("config/logging.properties")) {
            // Cargar configuración del archivo de propiedades
            LogManager.getLogManager().readConfiguration(fis);
        } catch (IOException e) {
            System.err.println("No se pudo cargar logging.properties: " + e.getMessage());
            return;
        }

        // Crear el logger
        Logger logger = Logger.getLogger(MainFilter.class.getName());

        // Crear e inicializar el FileHandler
        try {
            FileHandler fileHandler = new FileHandler("./logs/logs.log", true);
            
            // Asignar formato al FileHandler
            fileHandler.setFormatter(new SimpleFormatter());

            // Aplicar el filtro personalizado MultiplicationFilter al FileHandler
            fileHandler.setFilter(new MultiplicationFilter());

            // Agregar el FileHandler al logger
            logger.addHandler(fileHandler);

            // Desactivar el parent handler para evitar logs en consola
            logger.setUseParentHandlers(false);

        } catch (IOException | SecurityException e) {
            System.err.println("Error al configurar el FileHandler: " + e.getMessage());
            return;
        }

        // Crear instancia de la calculadora
        calculator calc = new calculator();

        // Operaciones matemáticas
        logger.info("Realizando suma 3 + 4");
        double suma = calc.add(3, 4);
        logger.info("La suma de los dos números es: " + suma);

        logger.info("Realizando resta 7 - 2");
        double resta = calc.sub(7, 2);
        logger.info("La resta de los números es: " + resta);

        logger.info("Realizando multiplicación 5 * 2");
        double multiplicacion = calc.mul(5, 2);
        logger.info("La multiplicación de los números es: " + multiplicacion);

        logger.info("Realizando división 10 / 2");
        try {
            double division = calc.div(10, 2);
            logger.info("La división de los dos números es: " + division);
        } catch (ArithmeticException e) {
            logger.severe("Error en la división: " + e.getMessage());
        }

        logger.info("Fin del programa.");
    }
}