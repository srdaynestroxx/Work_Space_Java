package logs_filter;

import java.util.logging.Filter;
import java.util.logging.LogRecord;

/**
 * Filtro para permitir únicamente mensajes relacionados con multiplicaciones.
 */
public class MultiplicationFilter implements Filter {

    @Override
    public boolean isLoggable(LogRecord record) {
        // Permitir solo mensajes que contengan '*' o 'MULT'
        if (record.getMessage().contains("*") || record.getMessage().toUpperCase().contains("MULT")) {
            return true;
        }
        return false;
    }
}