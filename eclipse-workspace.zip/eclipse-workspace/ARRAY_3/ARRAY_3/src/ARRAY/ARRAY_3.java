package ARRAY;

import java.util.Scanner;

public class ARRAY_3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner scanner = new Scanner(System.in);

		// Definir un array de 5 elementos y rellenarlo con palabras.

		String[] palabra = new String[5];

		palabra[0] = "";
		palabra[1] = "";
		palabra[2] = ""; // revisar y termionar ejercicio
		palabra[3] = "";
		palabra[4] = "";

		System.out.println("ingresa una palabra a guardar en la posicion 0 : ");
		palabra[0] = scanner.next();

		System.out.println("ingresa una palabra a guardar en la posicion 1 : ");
		palabra[1] = scanner.next();

		System.out.println("ingresa una palabra a guardar en la posicion 2 : ");
		palabra[2] = scanner.next();

		System.out.println("ingresa una palabra a guardar en la posicion 3 : ");
		palabra[3] = scanner.next();

		System.out.println("ingresa una palabra a guardar en la posicion 4 : ");
		palabra[4] = scanner.next();

		System.out.println("tu palabra está guardada es : " + palabra[0] + " " + palabra[1] + " " + palabra[2] + " "
				+ palabra[3] + " " + palabra[4]);

		System.out.println("la palabra guardada en la posición 0 es :" + palabra[0]);
		System.out.println("la palabra guardada en la posición 1 es :" + palabra[1]);
		System.out.println("la palabra guardada en la posición 2 es :" + palabra[2]);
		System.out.println("la palabra guardada en la posición 3 es :" + palabra[3]);
		System.out.println("la palabra guardada en la posición 4 es :" + palabra[4]);

	}
}