package JunitsTests;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import app.Persona;

class PersonaTest {

	@Test//test de constructor vacio 
	void testPersona() {
				//instancio mi clase...
		Persona prsn = new Persona()	;	
		
		//uso assertNOtNull, para verificar que el objeto/constructor esta vacio
		assertNotNull(prsn,"el objeto persona deberia d eestar creado correctamente");
		
	}
	
	@Test//test de constructor con paramentros
	void testpersona2() {
		
		//declaro las varibales del constructor con paramentros con valores de prueba
		String nombre="Juanito";
		String apellido="perez";
		String DNI="12345678A";
										//Al no poner lambdas"  ()->  ", Java intenta ejecutar los 
										//assertEquals antes de que assertAll pueda gestionarlos.
		//instancio mi clase
		Persona prsn = new Persona(nombre,apellido,DNI);//NO PODEMOS DEJAR EL OBJETO VACIO,por el le meto lo que testeo
			
		//usare assertALL para agrupar todas las comprbaciones de los atributos en una en una sola ejecución
		assertAll("verifico los atributos de la persona",()->
		assertEquals(nombre,prsn.getNombre(),"conseguimos el nombre de la persona( no coincide )"),()->
		assertEquals(apellido,prsn.getApellido(),"conseguimos el apellido de la persona( no coincide) "),()->
		assertEquals(DNI,prsn.getDNI(),"conseguimos el apellido de la persona(no coincide )"));
		
	}
	
	@Test//getters y setters
	
	
	

}
