package Arrays;

import java.util.Arrays;
import java.util.Scanner;

public class ARRAYS_6 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		boolean lista = false;
		// Definir el array de 5 elementos y rellenarlo de nombres.
		// Pedir un nombre al usuario e indicarle si está en el array o no.
		Scanner daymer = new Scanner(System.in);

		// variable array con nombres
		String[] nombres = { "Pedro", "Pepito", "Gaizka", "Daymer", "Luis" };
		boolean existe = true;

		// esto para leer todos los nombres del array
		System.out.println("En lista hay 5 nombres, dime uno: ");
		String opcion = daymer.nextLine();

		for (int i = 0; i < nombres.length; i++) {
			if (opcion.equals(nombres[i])) {
				lista = true;
				break; //sale del for 
			}
		}
		if (lista == true) {
			System.out.println("el nombre esta en la lista");
		} else {
			System.out.println("el nombre no existe");
		}

	}
}