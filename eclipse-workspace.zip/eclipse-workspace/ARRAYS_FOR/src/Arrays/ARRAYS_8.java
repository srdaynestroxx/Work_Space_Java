package Arrays;

import java.util.Arrays;// Importa la clase Scanner para leer datos del teclado
import java.util.Scanner;

public class ARRAYS_8 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		// Rellena un array de 10 elementos con los números introducidos desde el
		// teclado.
		// Luego sacar el siguiente menú y desarrollar las opciones correspondientes:
		// 1.- Calcular y visualizar la suma.

		// 2.- Visualizar el número más alto.

		// 3.- Visualizar el número más pequeño.

		// 4.- Pedir un número y visualizar el número de veces que aparece en el array.
		Scanner daymer = new Scanner(System.in);
		int numero[] = new int[10];
		int num = 0;

		for (int i = 0; i < numero.length; i++) {
			System.out.println("Introduce el número " + (i + 1) + ":");
			numero[i] = daymer.nextInt(); // aquí guardas cada número en el array
		}
		System.out.println("Inserta un número del 1 al 4 para ejecutar las funciones del menú :");
		int opcion = daymer.nextInt();

		switch (opcion) {
		case 1:
			int suma = 0;
			for (int i = 0; i < numero.length; i++) {
				suma += numero[i];
			}
			System.out.println("Calcular y visualizar la suma: " + suma);
			break;

		case 2:
			int max = numero[0];
			for (int i = 1; i < numero.length; i++) {
				if (numero[i] > max)
					max = numero[i];
			}
			System.out.println("El número más alto es: " + max);
			break;

		case 3:
			int min = numero[0];
			for (int i = 1; i < numero.length; i++) {
				if (numero[i] < min)
					min = numero[i];
			}
			System.out.println("El número más pequeño es: " + min);
			break;

		case 4:
			System.out.println("¿Qué número quieres buscar?");
			int buscado = daymer.nextInt();
			int contador = 0;
			for (int i = 0; i < numero.length; i++) {
				if (numero[i] == buscado)
					contador++;
			}
			System.out.println("El número " + buscado + " aparece " + contador + " veces.");
			break;

		default:
			System.out.println("Opción no válida");
		}

	}
}