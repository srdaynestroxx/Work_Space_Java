package Arrays;

import java.util.Scanner;

public class ARRAYS_3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		// Leer un número n y definir un array, de n elementos y rellenarlo
		// con los números creados aleatoriamente del 1 al 10:
		// (int)Math.floor(Math.random()*11);

		Scanner daymer = new Scanner(System.in);

		int n = 0;
		int[] array = new int[n];

		System.out.println("Introduce el array del 1 al 10:");
		n = daymer.nextInt();

		for (int i = 0; i < array.length; i++) {
			array[i] = (int) Math.floor(Math.random() * 11);
			System.out.println(array[i]);

		}

	}

}
