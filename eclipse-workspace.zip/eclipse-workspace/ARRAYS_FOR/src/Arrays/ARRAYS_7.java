package Arrays;

import java.util.Arrays;// Importa la clase Scanner para leer datos del teclado
import java.util.Scanner;

public class ARRAYS_7 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		//	Leer un número n y definir un array de esa longitud.
		// Rellena con números aleatorios del 1 al 10 y luego visualiza en pantalla el
		// más alto.
		Scanner daymer = new Scanner(System.in);
		
		int max = Integer.MIN_VALUE;
		int n = 0;
		
		
		//solicita al ususario que meta 10 numeros 
		System.out.println("porfavor inserte el numero del array: ");
		n= daymer.nextInt();
		int numN[] = new int[n];
		
		for(int i =0 ; i<numN.length ; i++) {//recorre lo numeroa metidos en pantalla 
		numN[i] = (int)Math.floor(Math.random()*11);//formula que da numeros random segun el numero q metamos
		System.out.println("en la primera posicion estara "+i+" es "+numN[i]); //ordena 
		if(numN[i]>max) {
			max=numN[i];

		}
		}
		System.out.println("el numero mas grande es : "+max );
		daymer.close();
			

	
	}
}