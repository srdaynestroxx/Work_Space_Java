package Arrays;

import java.util.Arrays;
import java.util.Scanner;

public class ARRAYS_5 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		// Al ejercicio 2 añadir que las palabra se visualicen en pantalla.

		Scanner daymer = new Scanner(System.in);

		// variable array con nombres
		String[] nombres = { "Adrian", "juan", "Aritz", "Ana", "pedro" };

		// esto para leer todos los nombres del array
		System.out.println("los nombres que hay en lista son: " + Arrays.toString(nombres));

		for (int i = 0; i < nombres.length; i++) {
			
			if (nombres[i].startsWith("A")) {
				System.out.println("los nombres por pantalla que inician con A son : " + nombres[i]);

			}

		}
	}
}