package Arrays;


public class ARRAYS_4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		 //Al ejercicio 2 añadir que las palabra se visualicen en pantalla.

		String[] palabra = new String[5];

		palabra[0] = "hola";
		palabra[1] = "eres";
		palabra[2] = "una"; // revisar y termionar ejercicio
		palabra[3] = "persona";
		palabra[4] = "increible";

		System.out.println("ingresa una palabra a guardar en la posicion 0 : "+palabra[0]);
		
		System.out.println("ingresa una palabra a guardar en la posicion 1 : "+palabra[1]);

		System.out.println("ingresa una palabra a guardar en la posicion 2 : "+palabra[2]);

		System.out.println("ingresa una palabra a guardar en la posicion 3 : "+palabra[3]);
		
		System.out.println("ingresa una palabra a guardar en la posicion 4 : "+palabra[4]);


	}
}