package base;

public class Sistema {

    // Paso 1: Devuelve nombre de usuario
    public String obtenerNombreUsuario() {
        return "Juan";
    }

    // Paso 2: Comprueba si el usuario está logueado
    public boolean estaLogueado() {
        return true;
    }

    // Paso 3: Busca un producto en catálogo
    public Object buscarProducto(String nombre) {
        // Por ahora no existe ningún producto
        return null;
    }

    // Paso 4: Devuelve un array de notas
    public int[] obtenerNotas() {
        return new int[] {5, 7, 9};
    }

    // Paso 5: Devuelve un objeto para comprobar referencia
    public Object obtenerObjetoSingleton() {
        Object obj = new Object();
        return obj;
    }
}
