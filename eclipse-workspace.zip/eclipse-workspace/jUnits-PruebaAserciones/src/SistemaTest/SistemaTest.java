package SistemaTest;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

import base.Sistema;

public class SistemaTest {

	@Test
	void testStrings() {

		Sistema sis = new Sistema();
		String NombreUsuario = sis.obtenerNombreUsuario();
		String UsuarioMayus = NombreUsuario.toUpperCase();
		assertEquals("JUAN", UsuarioMayus);

	}

	@Test
	void testbooleanos() {

		Sistema sis = new Sistema();
		boolean estaLogueado = sis.estaLogueado();
		// La prueba pasará si estaLogueado es true
		assertTrue(estaLogueado, "El usuario debería estar logueado al iniciar el sistema");
	}

	@Test
	void estNull() {
		Sistema sis = new Sistema();
		sis.buscarProducto("camiseta");
		assertNull(null, "El producto debería ser nulo si se busca con un parámetro nulo");

		/*
		 * @Test void estNull() { Sistema sis = new Sistema(); // 1. Usa el tipo de
		 * objeto real (ej: Producto) o 'var' var buscarProducto =
		 * sis.buscarProducto(null); // 2. Usa assertNull para verificar que sea nulo
		 * assertNull(buscarProducto,
		 * "El producto debería ser nulo si se busca con un parámetro nulo");
		 */
	}
	    @Test
	    void testObtenerNotas() {
	        Sistema sistema = new Sistema();
	        
	        // 1. Definir el array que esperamos recibir
	        int[] esperado = {5, 7, 9};        
	        // 2. Llamar al método creado
	        int[] actual = sistema.obtenerNotas();
	        // 3. Comprobar que coinciden
	        assertArrayEquals(esperado, actual, "El array de notas devuelto no coincide con el esperado");
	    }
	    
	    @Test
	    void testReferenciaSingleton() {
	        Sistema sistema = new Sistema();     
	        // Obtenemos la referencia dos veces
	        Object primeraVez = sistema.obtenerObjetoSingleton();
	        Object segundaVez = sistema.obtenerObjetoSingleton();       
	        // assertSame verifica que: primeraVez == segundaVez
	        assertSame(primeraVez, segundaVez, "Deberían ser la misma instancia de memoria");
	    }
	}

