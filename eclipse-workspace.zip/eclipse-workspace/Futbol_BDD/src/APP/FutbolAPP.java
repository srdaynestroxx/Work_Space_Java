package APP;

import java.sql.SQLException;
import java.util.Scanner;

import BDD.FutbolistaConnection;
import BDD.TaldeaConnect;
import Modelo.Futbolista;
import Modelo.Taldea;

public class FutbolAPP {

	public static void main(String[] args) throws SQLException {
		// TODO Auto-generated method stub
		int opcion = 0;
		FutbolistaConnection futcon = new FutbolistaConnection();
		TaldeaConnect talcon = new TaldeaConnect();
		Scanner sc = new Scanner(System.in);
		do {
			menuaErakutsi();
			opcion = Integer.parseInt(sc.nextLine());
			switch (opcion) {
			case 1:
				futbolariGuztiak(futcon);

				break;
			case 2:
				taldeGuztiak(talcon);
				break;

			case 3:
				futbolistaBerria(futcon, talcon);

				break;

			case 4:
				taldeBerria(talcon);

				break;
			case 5:
				System.out.println("Introduce el ID del jugador a visualizar");
				Scanner scan = new Scanner(System.in);
				String idJok = scan.nextLine();
				System.out.println(futcon.getFutbolistaIDtik(idJok));

				break;

			case 6:
				System.out.println("Introduce el ID del grupo a visualizar");
				scan = new Scanner(System.in);
				int idTal = Integer.parseInt(scan.nextLine());
				System.out.println(talcon.getTaldeaIDtik(idTal));
				break;

			case 7:
				System.out.println("Fin programa");
				break;
			default:
				break;

			}
		} while (opcion != 7);

	}

	private static void taldeBerria(TaldeaConnect talcon) throws SQLException {
		Scanner scan = new Scanner(System.in);
		System.out.println("Introduce el ID del nuevo equipo:");
		int idTaldea = Integer.parseInt(scan.nextLine());
		System.out.println("Introduce el nombre del nuevo equipo:");
		String izenTaldea = scan.nextLine();
		System.out.println("Introduce la población del nuevo equipo:");
		String hiria = scan.nextLine();

		Taldea taldeSortu = new Taldea();
		taldeSortu.setIdTaldea(idTaldea);
		taldeSortu.setIzena(izenTaldea);
		taldeSortu.setHerria(hiria);
		talcon.taldeaSortu(taldeSortu);
	}

	private static void futbolistaBerria(FutbolistaConnection futcon, TaldeaConnect talcon) throws SQLException {
		Scanner scan = new Scanner(System.in);
		boolean existe=false;
		System.out.println("Introduce el ID del nuevo jugador:");
		String idJokalari = scan.nextLine();
		System.out.println("Introduce el nombre del nuevo jugador:");
		String izenJokalari = scan.nextLine();
		System.out.println("Introduce el apellido del nuevo jugador:");
		String abizenJokalari = scan.nextLine();
		System.out.println("Introduce el ID del equipo del nuevo jugador:");
		int taldeaJokalari = Integer.parseInt(scan.nextLine());
		System.out.println("Introduce el salario del nuevo jugador:");
		double soldata = Double.parseDouble(scan.nextLine());
		
		for (int i = 0; i < talcon.getTaldeak().size(); i++) {
			if (taldeaJokalari == talcon.getTaldeak().get(i).getIdTaldea()) {
				Futbolista futSortu = new Futbolista();
				futSortu.setIdTaldea(taldeaJokalari);
				futSortu.setNan(idJokalari);
				futSortu.setIzena(izenJokalari);
				futSortu.setAbizena(abizenJokalari);
				futSortu.setSoldata(soldata);
				System.out.println(futSortu.toString());
				futcon.futbolistaSortu(futSortu);
				existe=true;
				break;

			} 
		}
		if (existe==false) {
			System.out.println("El equipo no existe");
		}
	}

	private static void taldeGuztiak(TaldeaConnect talcon) throws SQLException {
		System.out.println("Listado de equipos:");
		for (int i = 0; i < talcon.getTaldeak().size(); i++) {
			System.out.println(talcon.getTaldeak().get(i).toString());

		}
	}

	private static void futbolariGuztiak(FutbolistaConnection futcon) throws SQLException {
		System.out.println("Listado de futbolistas:");
		for (int i = 0; i < futcon.getFutbolistak().size(); i++) {
			System.out.println(futcon.getFutbolistak().get(i).toString());

		}
	}

	private static void menuaErakutsi() {
		System.out.println("BBDD de futbol");
		System.out.println("¿Qué quieres hacer?");
		System.out.println("1- Visualizar todos los jugadores.");
		System.out.println("2- Visualizar todos los equipos.");
		System.out.println("3- Añadir jugador.");
		System.out.println("4- Añadir equipo.");
		System.out.println("5- Visualizar jugador por ID.");
		System.out.println("6- Visualizar equipo por ID.");
		System.out.println("7- Salir.");

	}

}
