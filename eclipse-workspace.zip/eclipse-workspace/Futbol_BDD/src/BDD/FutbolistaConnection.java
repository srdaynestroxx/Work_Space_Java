package BDD;

import java.sql.*;
import java.util.ArrayList;

import Modelo.Futbolista;

public class FutbolistaConnection {

	Connection connect() {

		Connection con = null;

		String url = "jdbc:mysql://localhost:3306/futbol_bdd";

		String username = "root";

		String password = "";

		try {

			con = DriverManager.getConnection(url, username, password);
			System.out.println("se ha conectado correctamente a la base de datos");

		} catch (Exception e) {

			// todo: handle exception

			e.printStackTrace();
		}

		return con;

		
	}
	public Futbolista getFutbolistaIDtik(String id) throws SQLException {
		Connection con = connect();
		Statement st = con.createStatement();
		String consulta= "SELECT * FROM futbolistas WHERE dni='"+id+"';";
        ResultSet resultSet = (ResultSet) st.executeQuery(consulta);
        Futbolista fut=new Futbolista();
        while (resultSet.next()) {
            String izena = resultSet.getString("nombre");
            String abizenak= resultSet.getString("apellido");
            Double soldata = resultSet.getDouble("salario");
            int taldea= resultSet.getInt("idEquipo");
            fut = new Futbolista(id, izena, abizenak, soldata, taldea);
        }
		return fut;
	}
	
	
	public void futbolistaSortu(Futbolista fut) throws SQLException {
		Connection con = connect();
		Statement st = con.createStatement();
		String consulta= "INSERT INTO futbolistas "
				+ "(dni, nombre, apellido, salario, idEquipo) VALUES ('"+fut.getNan()+"', '"+fut.getIzena()+"', '"+
				fut.getAbizena()+"', '"+fut.getSoldata()+"', '"+fut.getIdTaldea()+"');";
		boolean emaitza=st.execute(consulta);
		/*if (emaitza==true) {
			System.out.println("El futbolista se ha creado correctamente.");
		}else {
			System.out.println("El futbolista no se ha creado.");
		}*/
		con.close();
	}
	public void futbolistaEzabatu(String NANFut) throws SQLException {
		Connection con = connect();
		Statement st = con.createStatement();
		String consulta= "DELETE FROM usuarios WHERE id='"+NANFut+"'";
        
		st.execute(consulta);
		
		
	}
	public ArrayList<Futbolista> getFutbolistak() throws SQLException {
		Connection con = connect();
		Statement st = con.createStatement();
		String consulta= "SELECT * FROM futbolistas;";
        ResultSet resultSet = (ResultSet) st.executeQuery(consulta);
		ArrayList<Futbolista> futbolistaList=new ArrayList<Futbolista>();
		try {
        while (resultSet.next()) {
        	Futbolista fut =new Futbolista(); 
            fut.setNan(resultSet.getString("dni"));
            fut.setIzena(resultSet.getString("nombre"));
            fut.setAbizena(resultSet.getString("apellido"));
            fut.setSoldata(resultSet.getInt("salario"));
            fut.setIdTaldea(resultSet.getInt("idEquipo"));
            futbolistaList.add(fut);
        }
        }
        catch (Exception e) {
        	System.err.println("Error en getFutbolistak");
        }
		return futbolistaList;
	}
	

}


