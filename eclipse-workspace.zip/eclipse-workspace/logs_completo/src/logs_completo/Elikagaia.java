package logs_completo;

public class Elikagaia {

    private String izena;
    private String egoera;
    private double kaloriak;
    private double koipeak;
    private double proteinak;
    private double karbohidratoak;
    private String mota;

    // Parametrorik gabeko sortzailea
    public Elikagaia() {
        this.izena = "";
        this.egoera = "";
        this.kaloriak = 0.0;
        this.koipeak = 0.0;
        this.proteinak = 0.0;
        this.karbohidratoak = 0.0;
        this.mota = "";
    }

    // Parametrodun sortzailea
    public Elikagaia(String izena, String egoera, double kaloriak, double koipeak,
                     double proteinak, double karbohidratoak, String mota) {

        this.izena = izena;
        this.egoera = egoera;
        this.kaloriak = kaloriak;
        this.koipeak = koipeak;
        this.proteinak = proteinak;
        this.karbohidratoak = karbohidratoak;
        this.mota = mota;
    }

    // Getters eta Setters
    public String getIzena() { return izena; }
    public void setIzena(String izena) { this.izena = izena; }

    public String getEgoera() { return egoera; }
    public void setEgoera(String egoera) { this.egoera = egoera; }

    public double getKaloriak() { return kaloriak; }
    public void setKaloriak(double kaloriak) { this.kaloriak = kaloriak; }

    public double getKoipeak() { return koipeak; }
    public void setKoipeak(double koipeak) { this.koipeak = koipeak; }

    public double getProteinak() { return proteinak; }
    public void setProteinak(double proteinak) { this.proteinak = proteinak; }

    public double getKarbohidratoak() { return karbohidratoak; }
    public void setKarbohidratoak(double karbohidratoak) { this.karbohidratoak = karbohidratoak; }

    public String getMota() { return mota; }
    public void setMota(String mota) { this.mota = mota; }

    @Override
    public String toString() {
        return izena + " (" + egoera + ") - Kcal: " + kaloriak +
                " | Koipeak: " + koipeak +
                " | Proteinak: " + proteinak +
                " | Karbohidratoak: " + karbohidratoak +
                " | Mota: " + mota;
    }
}
