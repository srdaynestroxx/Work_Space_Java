package logs_completo;

import java.util.logging.*;

public class HtmlFormatte extends Formatter {

    @Override
    public String getHead(Handler h) {
        return "<html><head><style>"
            + "table { width:100%; border-collapse: collapse; }"
            + "th, td { border:1px solid #888; padding:4px; }"
            + "th { background: #eee; }"
            + "</style></head><body>"
            + "<h2>NutriscoreAPP - Registro de eventos</h2>"
            + "<table><tr>"
            + "<th>Fecha</th><th>Nivel</th><th>Logger</th><th>Mensaje</th>"
            + "</tr>";
    }

    @Override
    public String format(LogRecord record) {
        return "<tr><td>" + new java.util.Date(record.getMillis()) + "</td>"
            + "<td>" + record.getLevel() + "</td>"
            + "<td>" + record.getLoggerName() + "</td>"
            + "<td>" + formatMessage(record) + "</td></tr>";
    }

    @Override
    public String getTail(Handler h) {
        return "</table></body></html>";
    }
}