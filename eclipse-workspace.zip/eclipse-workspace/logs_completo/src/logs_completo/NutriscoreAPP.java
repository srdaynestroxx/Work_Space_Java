package logs_completo;

import java.io.*;
import java.util.*;

public class NutriscoreAPP {

    private static ArrayList<Elikagaia> lista = new ArrayList<>();

    public static void main(String[] args) {
        cargarDesdeArchivo();
        menuPrincipal();
        guardarEnArchivo();
    }

    // CARGAR DESDE ARCHIVO
    public static void cargarDesdeArchivo() {
        try {
            BufferedReader br = new BufferedReader(new FileReader("./fichero.txt/janariak(1).txt"));
            String linea;

            while ((linea = br.readLine()) != null) {
                String[] z = linea.split(";");

                Elikagaia e = new Elikagaia(
                        z[0],
                        z[1],
                        Double.parseDouble(z[2]),
                        Double.parseDouble(z[3]),
                        Double.parseDouble(z[4]),
                        Double.parseDouble(z[5]),
                        z[6]
                );
                lista.add(e);
            }

            br.close();
            System.out.println("Datos cargados correctamente (" + lista.size() + " alimentos).");

        } catch (Exception e) {
            System.out.println("Error al leer el archivo: " + e.getMessage());
        }
    }

    // GUARDAR EN ARCHIVO
    public static void guardarEnArchivo() {
        try {
            PrintWriter pw = new PrintWriter(new FileWriter("janariak_out.txt"));

            for (Elikagaia e : lista) {
                pw.println(
                    e.getIzena() + ";" + e.getEgoera() + ";" + e.getKaloriak() +
                    ";" + e.getKoipeak() + ";" + e.getProteinak() +
                    ";" + e.getKarbohidratoak() + ";" + e.getMota()
                );
            }
            pw.close();
            System.out.println("Datos guardados en el archivo janariak_out.txt.");

        } catch (Exception e) {
            System.out.println("Error al guardar: " + e.getMessage());
        }
    }

    // MENU PRINCIPAL
    public static void menuPrincipal() {
        Scanner sc = new Scanner(System.in);
        int opcion = -1;

        do {
            System.out.println("\n===== MENÚ NUTRISCORE =====");
            System.out.println("1. Buscar alimento");
            System.out.println("2. Mostrar alimentos");
            System.out.println("3. Calcular calorías");
            System.out.println("0. Salir");
            System.out.print("Opción: ");

            try {
                opcion = sc.nextInt();
                sc.nextLine(); // Limpiar buffer

                switch (opcion) {
                    case 1: buscar(sc); break;
                    case 2: mostrar(sc); break;
                    case 3: calcularCalorias(sc); break;
                    case 0: System.out.println("Saliendo del programa..."); break;
                    default: System.out.println("Opción incorrecta.");
                }
            } catch (InputMismatchException e) {
                System.out.println("Por favor, ingrese un número.");
                sc.nextLine(); // Limpiar entrada incorrecta
            }

        } while (opcion != 0);
    }

    // 1. BUSCAR ALIMENTO
    public static void buscar(Scanner sc) {
        System.out.print("Ingrese el nombre del alimento: ");
        String nombre = sc.nextLine().toLowerCase();

        boolean encontrado = false;
        for (Elikagaia e : lista) {
            if (e.getIzena().toLowerCase().equals(nombre)) {
                System.out.println(e);
                encontrado = true;
            }
        }

        if (!encontrado)
            System.out.println("El alimento no existe.");
    }

    // 2. MOSTRAR ALIMENTOS
    public static void mostrar(Scanner sc) {
        System.out.print("Posición inicial: ");
        int pos = sc.nextInt();
        System.out.print("Cantidad a mostrar: ");
        int cantidad = sc.nextInt();

        for (int i = pos; i < pos + cantidad && i < lista.size(); i++) {
            System.out.println(lista.get(i));
        }
    }

    // 3. CALCULAR CALORÍAS
    public static void calcularCalorias(Scanner sc) {
        System.out.print("Nombre: ");
        String nombre = sc.nextLine().toLowerCase();

        System.out.print("Estado: ");
        String estado = sc.nextLine().toLowerCase();

        System.out.print("Peso (g): ");
        double gramos = sc.nextDouble();

        for (Elikagaia e : lista) {
            if (e.getIzena().toLowerCase().equals(nombre) &&
                e.getEgoera().toLowerCase().equals(estado)) {

                double kcal = e.getKaloriak() * gramos / 100.0;
                System.out.println("Total: " + kcal + " kcal");
                return;
            }
        }
        System.out.println("No se encontró el alimento.");
    }
}
