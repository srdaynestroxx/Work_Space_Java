package Metodos;

import java.util.Scanner;

public class Metodos5 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

//		Es necesario crear un método (procedimiento) 
//		calcularAreaTriangulo que reciba la base y la altura y escriba en pantalla su área

		Scanner daymer = new Scanner(System.in);
			
		System.out.println("introduce la base :");
		int base = daymer.nextInt();

		System.out.println("introduce la altura :");
		int altura = daymer.nextInt();

		int area = calcularAreaTriangulo(base, altura);

	}

	public static int calcularAreaTriangulo(int base, int altura) {//int base,int altura son los paramewtros de entrada
// int es lo que indica el tipo de dato que el método va a devolver con la palabra return.
		 
		int base * int altura = 
		
		return;
	}
}