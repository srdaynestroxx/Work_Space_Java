package Metodos;

import java.util.Scanner;

public class metodos4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub


//	    Es necesario crear un método (función) llamado calcularAreaCirculo.
//		Parámetros recibidos: int diámetro y devolverá un double con el área.
//		Utilizamos el ejercicio para ver Math.PI y Math.Pow 
// 		del import java.lang.Math;cómo y cómo limitar la visualización de posiciones decimales: 

//	    double valor = 123.456789;

//	    String.format("%.3f", valor)     

//	    Muestra: 123.456
		
		Scanner daymer = new Scanner(System.in);
		
		System.out.println("introduce el diametro del circulo :");
		int diametro = daymer.nextInt();
		
		double area = calcularAreaCirculo(diametro);
		
		System.out.println("El área del círculo es: " + String.format("%.3f", area));
//		% → indica que viene un valor numérico
//		.3 → número de decimales (3)
//		f → formato float/double (número decimal)

        daymer.close();
		
		
	}//En Java no se puede declarar un método dentro de otro método (lo cierro aqui)
		
		public static double calcularAreaCirculo(int diametro) { //double — tipo de retorno-Parámetro: int diametro
												//parámetros de entrada int diametro
			//double indica el tipo de dato que el método va a devolver con la palabra return.
			
			double radio = diametro / 2.0;  //se multiplica pi x radio al cuadrado que lo represewnton asi..
			double area = Math.PI * Math.pow(radio, 2); // <---
			
			return area; 
//	devuelve el resultado calculado (el área del círculo) al lugar donde se llamó el método
	
		

	}

}