package Metodos;

import java.util.Scanner;

public class Metodos2 {

	public static void main(String[] args) {

//		Es necesario crear un método (función) que reciba un double “cantidadDeDinero” y un char
//		“monedaDeCambio”.
//		Si recibe una "D" quiere decir que la cantidad está en Euros y tiene que devolver en Dólares.
//		Si recibe una "E" quiere decir que la cantidad está en Dólares y tiene que devolver en Euros.
//		Tiene que funcionar con “monedaDeCambio” en mayúsculas y minúsculas.
		Scanner daymer = new Scanner(System.in);

		double dolarCambio;
		double cantidadDinero;
		double CantidadDineroConvertida;
		char monedaDeCambio;
		String monedaCambioString;

		System.out.println("Cuanto dinero quieres introducir ?");
		cantidadDinero = daymer.nextDouble();

		System.out.println("convierte el dolar en euro insertando 'E' o convierte el dolar en euro insertando 'D': ");
		monedaDeCambio = daymer.next().charAt(0);

		if (monedaDeCambio == 'E' || monedaDeCambio == 'e') {
			CantidadDineroConvertida = cantidadDeDineroDolar(cantidadDinero);
			System.out.println(cantidadDinero + " € " + " = " + CantidadDineroConvertida + " $ ");

		} else if (monedaDeCambio == 'D' || monedaDeCambio == 'd') {
			CantidadDineroConvertida = cantidadDeDineroEuro(cantidadDinero);
			System.out.println(cantidadDinero + " $ " + " = " + CantidadDineroConvertida + " € ");
		}

	}

	public static double cantidadDeDineroEuro(double euro) {
		// convertir de euro a dolar
		double dolar;
		double cambio = 1.17;
		dolar = euro * cambio;
		return dolar;

	}

	public static double cantidadDeDineroDolar(double dolar) {
		// convertir de dolar a euro
		double euro;
		double cambio = 0.85;
		euro = dolar * cambio;
		return euro;
	}
}
