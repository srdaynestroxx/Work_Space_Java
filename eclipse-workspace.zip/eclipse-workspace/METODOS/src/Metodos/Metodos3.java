	package Metodos;
	
	import java.util.Scanner;
	
	public class Metodos3 {
	
		public static void main(String[] args) {
	
			// Es necesario crear un método (procedimiento) que escriba en pantalla el
			// cambio entre diferentes monedas. Recibirá 3 parámetros:
			// double cantidad
			// char monedaIn: posibles valores: E, D, B -> euro, dolar, bitcoin
			// char modedaOut: posibles valores: E, D, B -> euro, dolar, bitcoin
			// Deberá realizar el cambio de monedaIn a monedaOut y escribir en
			// pantalla.
			Scanner daymer = new Scanner(System.in);
	
			double cantidadDinero;
			char monedaIn;
			char monedaOut;
	
			System.out.println("Cuanto dinero quieres introducir ?");
			cantidadDinero = daymer.nextDouble();
	
			System.out.println("introduce la entrada de la moneda E(euro), D(dolar), B(bitcoin)");
			monedaIn = daymer.next().charAt(0);
	
			System.out.println("introduce la salida de la moneda E(euro), D(dolar), B(bitcoin)");
			monedaOut = daymer.next().charAt(0);
	
			if ((monedaIn == 'E' || monedaIn == 'e') && (monedaOut == 'D' || monedaOut == 'd')) {
				cantidadDeDineroEuro(cantidadDinero);
			}
			
			 else if ((monedaIn == 'D' || monedaIn == 'd') && (monedaOut == 'E' || monedaOut == 'e')) {
				cantidadDeDineroDolar(cantidadDinero);
			}
			
			 else if ((monedaIn == 'D' || monedaIn == 'd') && (monedaOut == 'B' || monedaOut == 'b')) {
			cantidadDedineroDolarBitcoin(cantidadDinero);
			}
			
			 else if ((monedaIn == 'B' || monedaIn == 'b')  && (monedaOut == 'D' || monedaOut == 'd')) {
				cantidadDedineroBitcoinDolar(cantidadDinero);
			 }
			 
			else if((monedaIn == 'E' || monedaIn == 'e') && (monedaOut == 'B' || monedaOut == 'b' )){
				cantidadDedineroEuroBitcoin(cantidadDinero);
			}
			
			else if((monedaIn == 'B' || monedaIn == 'b') && (monedaOut == 'E' || monedaOut == 'e' )) {
				cantidadDedineroBitcoinEuro(cantidadDinero);			}
		}
	
		public static void cantidadDeDineroEuro(double euro) {
			// convertir de euro a dolar
			double dolar;
			double cambio = 1.17;
			dolar = euro * cambio;
			System.out.println(euro+" € = "+dolar+" $");	
		}
	
		public static void cantidadDeDineroDolar(double dolar) {
			// convertir de dolar a euro
			double euro;
			double cambio = 0.86;
			euro = dolar * cambio;
			System.out.println(dolar+" $ = "+euro+" €");	
		}
	
		public static void cantidadDedineroDolarBitcoin(double bitcoin) {
			// convertir de dolar a bitcoin
			double dolar = 0;
			double cambio = 0.0000090;
			dolar = bitcoin * cambio;
			System.out.println(dolar+" $ = "+bitcoin+" ₿");	
		}
	
		public static void cantidadDedineroBitcoinDolar(double bitcoin1) {
			// convertir de bitcoin a dolar
			double dolar;
			double cambio = 108052.89 ;
			dolar = bitcoin1 * cambio;
			System.out.println(bitcoin1+" ₿ = "+dolar+" $");	

		}
	
		public static void cantidadDedineroEuroBitcoin(double bitcoin2) {
			// convertir de euro a bitcoin
			double euro = 0;
			double cambio = 0.000010;
			euro = bitcoin2 * cambio;
			System.out.println(euro+" € = "+bitcoin2+" ₿");	
		}
		
		public static void cantidadDedineroBitcoinEuro(double bitcoin3 ) {
			// convertir de bitcoin a Euro
						double euro = 0;
						double cambio = 95428.11;
						euro = bitcoin3 * cambio;
						System.out.println(euro+" € = "+bitcoin3+" ₿");	
	} 
	}