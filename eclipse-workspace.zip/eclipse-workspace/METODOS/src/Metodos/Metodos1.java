package Metodos;

import java.util.Scanner;

public class Metodos1 {

	public static void main(String[] args) {

//		Es necesario crear una método (función) para que convierta, 
//		la cantidad introducida de Euros a Dólares.
		
		Scanner daymer = new Scanner(System.in);

		double euro;

		System.out.println("introduce la cantidad de euros :");
		euro = daymer.nextDouble();

		daymer.close();

		double dolar = euro_dolar(euro);
		System.out.println(euro + "€" + " = " + dolar + " $ ");

	}

	public static double euro_dolar(double eurox) {

		double dolarx;
		double cambio = 1.17;
		dolarx = eurox * cambio;
		return dolarx;

	}
}