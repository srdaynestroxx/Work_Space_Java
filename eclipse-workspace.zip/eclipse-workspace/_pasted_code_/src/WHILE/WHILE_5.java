package WHILE;

public class WHILE_5 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		//Escribir un programa que imprima los números pares
		//positivos menores o iguales que 20 en orden descendiente.
		
		int contador = 0;
		
		while(contador <= 20) {
			
			System.out.println(contador);
			
			contador+=2;
		}
	}

}