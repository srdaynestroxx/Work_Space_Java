package logs_fichero;

import java.io.IOException;
import java.util.logging.FileHandler;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.logging.SimpleFormatter;

public class MainLoggerFichero {
    
    // El nombre del logger debe ser el de la clase donde se configura
    private static final Logger LOGGER = Logger.getLogger(MainLoggerFichero.class.getName());

    public static void main(String[] args) {

        // 1. CONFIGURACIÓN DEL LOGGER y NIVEL GLOBAL
        // El nivel global debe ser INFO, como pide el enunciado
        LOGGER.setLevel(Level.INFO); 
        LOGGER.setUseParentHandlers(false);
        
        try {
            // Creación del FileHandler
            // El enunciado pide "logs/calculadora.log"
            FileHandler fileHandler = new FileHandler("./logFichero/ficheroLog/fichero.log"); 
            
            // Asignación de SimpleFormatter
            fileHandler.setFormatter(new SimpleFormatter());

            // El nivel del Handler debe ser al menos INFO
            fileHandler.setLevel(Level.INFO); 
            
            // Asignar Handler al Logger
            LOGGER.addHandler(fileHandler);

            LOGGER.info("Inicio del programa de calculadora. Logs se guardan en logs/calculadora.log");

        } catch (IOException exception) {
            System.err.println("Error al configurar FileHandler: " + exception.getMessage());
            LOGGER.log(Level.SEVERE, "Ocurrió un error grave en la configuración del Logger.", exception);
            return;
        }

        // --- Lógica de la Aplicación y Registro de Mensajes ---
        
        // 4. EL MENSAJE 'finer' NO APARECERÁ porque el nivel es INFO
        // LOGGER.finer("Ejemplo con log FINEST/FINER no aparecerá."); 

        calculator calculator = new calculator();
        double num1 = 10.0;
        double num2 = 5.0;
        double result;

        // Suma
        LOGGER.info("Iniciando operación: add(" + num1 + ", " + num2 + ")");
        result = calculator.add(num1, num2);
        LOGGER.info("Resultado ooobtenido: " + result);
        // También puedes usar System.out para la salida normal de la aplicación
        System.out.println("Suma: " + result);

        // Resta
        LOGGER.info("Iniciando operación: sub(" + num1 + ", " + num2 + ")");
        result = calculator.sub(num1, num2);
        LOGGER.info("Resultado obtenido: " + result);
        System.out.println("Resta: " + result);

        // Multiplicación
        LOGGER.info("Iniciando operación: mul(" + num1 + ", " + num2 + ")");
        result = calculator.mul(num1, num2);
        LOGGER.info("Resultado obtenido: " + result);
        System.out.println("Multiplicación: " + result);

        // División (Caso Exitoso)
        LOGGER.info("Iniciando operación: div(" + num1 + ", " + num2 + ")");
        try {
            result = calculator.div(num1, num2);
            LOGGER.info("Resultado obtenido: " + result);
            System.out.println("División exitosa: " + result);
        } catch (ArithmeticException ignored) {
            // No se ejecutará aquí
        }

        // División (Caso Error)
        double num3 = 0.0;

        LOGGER.info("Iniciando operación: div(" + num1 + ", " + num3 + ")");
        try {
            result = calculator.div(num1, num3);
            LOGGER.info("Resultado obtenido: " + result); // No se ejecutará
            System.out.println("División por cero: " + result); 
        } catch (ArithmeticException e) {
            // 3. Manejar excepción y registrar mensaje SEVERE
            LOGGER.log(Level.SEVERE, "Error detectado: División por cero no permitida");
            System.err.println("Error detectado: " + e.getMessage()); 
        }
    }
}