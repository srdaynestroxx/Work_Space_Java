package ARRAY;

import java.util.Scanner;

public class ARRAY_1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner scanner = new Scanner(System.in);

		// Definir un array de 5 elementos y rellenarlo con palabras.

		String[] palabra = new String[5];

		palabra[0] = "Hola";
		palabra[1] = "estoy";
		palabra[2] = "aprendiendo";
		palabra[3] = "arrays";
		palabra[4] = "; )";

		for (int i = 0; i < palabra.length; i++) {
			// int i = 0; -> inicialización, el contador empieza en 0
			// i < palabra.length -> condición, mientras i sea menor que la longitud del
			// array se repite el bucle
			// i++ -> incremento, después de cada vuelta aumenta i en 1
			System.out.println(palabra[i]);
			// Diferencia clave:
			//
			// System.out.println(...)
			// → Imprime lo que le pasas y luego hace un salto de línea (\n).
			// → Resultado: cada elemento se imprime uno debajo del otro.
			//
			// System.out.print(...)
			// → Imprime lo que le pasas sin salto de línea.
			// → Resultado: todo se muestra seguido en la misma línea.

		}
	}

}