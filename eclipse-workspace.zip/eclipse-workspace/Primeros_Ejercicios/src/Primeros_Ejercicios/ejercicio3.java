package Primeros_Ejercicios;

import java.util.Scanner; //import scanner 

public class ejercicio3 {

public static void main(String[] args) {
				
				String nombre;//variable declaracion
				Scanner scanner = new Scanner(System.in); //lector del scanner 

				System.out.println("¿ cual es tu nombre ?");//mensaje en pamtalla de nombre 
				nombre = scanner.next();//output para meter tu nombre en pantalla 
				
				System.out.println("tu nombre es : "+nombre);//te da el nombre y te concatena con la variable para decirte el nombre 
															//puesto en pantalla 
				
				scanner.close(); //se cierra el escanner 
			}

		

	}

