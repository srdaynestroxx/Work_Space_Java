package Primeros_Ejercicios;

import java.util.Scanner; //import scanner 

public class ejercicio5 {

	public static void main(String[] args) {

		int num1 = 0;
		int num2 = 0;	//declaracion de variables a 0
		int num3 = 0;
		int resultado = 0;
		
		Scanner scanner = new Scanner(System.in); //lector del scanner 

		System.out.println("introduce un numero a multiplicar : ");
		num1 = scanner.nextInt();//output para meter tu numero en pantalla y almacenar el numero 
								//metido en pantalla
		
		System.out.println("introduce un segundo numero : ");
		num2 = scanner.nextInt();//output para meter tu numero en pantalla y almacenar el numero 
								//metido en pantalla
		

		System.out.println("introduce un tercer numero : ");
		num3 = scanner.nextInt();//output para meter tu numero en pantalla 
 
		resultado = num1 * num2 * num3; //hace la multiplocacion
		System.out.println("El resultado de la division es : "+resultado);//imprime la multiplicacion
	
		
	}

}
