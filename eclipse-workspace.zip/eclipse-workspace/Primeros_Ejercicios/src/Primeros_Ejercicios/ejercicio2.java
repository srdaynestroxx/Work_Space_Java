package Primeros_Ejercicios;

import java.util.Scanner;

public class ejercicio2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	

				
				String nombre;//variable declaracion
				Scanner scanner = new Scanner(System.in); //lector del scanner 

				System.out.println("¿ cual es tu nombre ?");//mensaje en pamtalla de nombre 
				nombre = scanner.next();//output para meter tu nombre en pantalla 
				
				System.out.println(nombre);//te da el nombre y te concatena con la variable para decirte el nombre 
															//puesto en pantalla 
				
				scanner.close(); //se cierra el escanner 
			}

	}


