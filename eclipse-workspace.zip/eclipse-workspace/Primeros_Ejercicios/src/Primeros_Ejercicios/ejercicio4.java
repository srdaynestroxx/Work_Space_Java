package Primeros_Ejercicios;

import java.util.Scanner; //import scanner 

public class ejercicio4 {

	public static void main(String[] args) {

		int num1 = 0;
		int num2 = 0;
		int resultado = 0;
	
		
		Scanner scanner = new Scanner(System.in); //lector del scanner 

		System.out.println("introduce un numero : ");
		num1 = scanner.nextInt();;//output para meter tu numero en pantalla y almacenar el numero 
								//metido en pantalla
		
		System.out.println("introduce otro numero : ");
		num2 = scanner.nextInt();//output para meter tu numero en pantalla y almacenar el numero 
									//metido en pantalla

		resultado = num1 + num2;
		System.out.println("La suma de los numeros es: "+resultado);
		
	}

}
