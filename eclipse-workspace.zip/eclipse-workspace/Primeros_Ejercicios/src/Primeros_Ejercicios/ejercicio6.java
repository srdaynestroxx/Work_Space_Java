package Primeros_Ejercicios;

import java.util.Scanner; //import scanner 

public class ejercicio6 {

	public static void main(String[] args) {

		Scanner scanner = new Scanner(System.in); //lector del scanner 

		//pedir la temperatura em grados celsius 
		System.out.print("Ingrese la temperatura en grados Celsius: ");
		
		//double para almacenar números de punto flotante (con decimales ejemplo precio = 19.99;  )
	//que requieren una alta precisión y un rango amplio de valores.
		
		//La temperatura ingresada por el usuario debe ser leída y almacenada 
		//en una variable de tipo double
		double celsius = scanner.nextDouble();

		//Se debe aplicar la fórmula de conversión para calcular la temperatura en grados  
		//Esto se puede expresar en Java como double fahrenheit = celsius * 1.8 + 32;. 
		double fahrenheit = celsius * 1.8 + 32;
		
		
		//se debe imprimir el resultado, mostrando la temperatura en grados Fahrenheit. Por ejemplo
		System.out.println("La temperatura en grados Fahrenheit es: " + fahrenheit + " °F");
		
		//cierre del Scanner
		scanner.close();



		
	}

}
