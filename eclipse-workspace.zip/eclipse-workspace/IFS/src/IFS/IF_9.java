package IFS;

import java.util.*;

public class IF_9 {

	public static void main(String[] args) {

		//Pedir el usuario y la contraseña y decir si el login está bien. (usuario: ikaslea
		//contraseña: ik1920)
		
		String usuario = "ikaslea"; //variables 
		String contraseña = "ik1920";
		
		Scanner scanner = new Scanner(System.in); //lector del scanner 
		
		System.out.println("introduce tu usuario para acceder a tu cuenta :  ");
		String usuarioPuesto = scanner.next();//output para meter tu usuario en pantalla 
	
		
		
		
	if (usuarioPuesto.equals(usuario)) {
			
		System.out.println("usuario introducido con exito");

	}else  {
		
		System.out.println("el usuario introducido no es correcto");
	}
	
	System.out.println("introduce tu contraseña para acceder a tu cuenta :  ");
	String contraseñaPuesta = scanner.next();//output para meter tu contraseña en pantalla 


	if (contraseñaPuesta.equals(contraseña)) {
			
			System.out.println("contraseña introducida con exito");
			System.out.println("Bienvenido ;) ");


			
	}
	
	else {
		
		System.out.println("la contraseña introducida no es correcto");
		
	

	}
	

		scanner.close();
}
}