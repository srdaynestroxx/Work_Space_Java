package IFS;

import java.util.Scanner;

public class IF_10 {

	public static void main(String[] args) {

	 
		//Pedir tres números, una mayor que otra, si el usuario introduce menor o igual
		//visualizar mensaje de ERROR.
		
		int num1,num2,num3; //variables 
	
		Scanner scanner = new Scanner(System.in); //lector del scanner 
		
		System.out.println("dama 3 numeros:  ");
		num1 = scanner.nextInt();//output para meter tus numeros en pantalla 
		num2 = scanner.nextInt();//output para meter tus numeros en pantalla 
		num3  = scanner.nextInt();//output para meter tus numeros en pantalla 
		
		if(num1>=num2){
			System.out.println("error");
			
		}	else if (num2>=num3) {
			
			System.out.println("error");
		}
		else {
			
			
			System.out.println("los numeros introducidos van de menor a mayor ");
			
		}

		scanner.close();
}
}