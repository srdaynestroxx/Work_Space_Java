package IFS;

import java.util.Scanner; // Importa la clase Scanner para leer la entrada del usuario

public class IF_13 {

	public static void main(String[] args) {

        Scanner	num1 = new Scanner(System.in); // Crea un objeto Scanner para leer la entrada
	 
        
        
        int numNota; 
        
        
        // Pide al usuario que ingrese los números
        
        System.out.println("introduce numeros del 1 al 9 y yo te dire tu nota respectiva : ");
        numNota = num1.nextInt();
        
        if (numNota==1) {
        	
        	System.out.println("tu nota esta entre 1 y 4,9: suspenso");
        
        }
        if (numNota==5) {
        	
        	System.out.println("tu nota esta entre 5 y 5,9: suficiente");
        }
        
        if (numNota==6) {
        	
        	System.out.println("tu nota esta entre 6 y 6,9: bien");
        }
        
        if (numNota==7) {
        	
        	System.out.println("tu nota esta entre 7 y 8,9: muy bien");
        }
        
        if (numNota==9) {
        	
        	System.out.println("tu nota esta entre 9 y 10: sobresaliente");
        	
        }else if(numNota <= 999999)  {
        	
        	System.out.println("ERROR!!!!");
        
        }
        
        
        num1.close(); // Cierra el objeto Scanner para liberar recursos
    }
}
