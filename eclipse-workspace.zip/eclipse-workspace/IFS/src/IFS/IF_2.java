package IFS;

import java.util.Scanner;

public class IF_2 {

	public static void main(String[] args) {

		//Leer dos números y decir cuál es el mayor. ¿Qué pasa si los números introducidos son
		//de mismo valor?
		
		int num1 = 0; //variables 
		int num2 = 0;
		
		Scanner scanner = new Scanner(System.in); //lector del scanner 
		
		System.out.println("introduce un primer numero a comparar: ");
		num1 = scanner.nextInt();//output para meter tu numero en pantalla y almacenar el numero 
		//metido en pantalla
		
		System.out.println("introduce un segundo numero a comparar: ");
		num2 = scanner.nextInt();//output para meter tu numero en pantalla y almacenar el numero 
								//metido en pantalla
		
		if (num1 > num2) {
			
			System.out.println(" el "+num1+" es mayor que el "+num2+" ");

	} else if (num2 > num1) {
		System.out.println("el "+num2 +" numero es mayor que el "+num1+" ");
		
	}else {
		
		System.out.println("los numeros son iguales");
	}
			scanner.close();
}
}