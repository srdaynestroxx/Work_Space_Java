package IFS;

import java.util.Scanner; // Importa la clase Scanner para leer la entrada del usuario
import java.util.Arrays;  // Importa la clase Arrays para usar el método sort()

public class IF_15 {

	public static void main(String[] args) {

        Scanner	num = new Scanner(System.in); // Crea un objeto Scanner para leer la entrada
	 
        
        // Pide al usuario que ingrese tres números
        System.out.println("Introduce el primer número entero:");
        int num1 = num.nextInt(); // Lee el primer número

        System.out.println("Introduce el segundo número entero:");
        int num2 = num.nextInt(); // Lee el segundo número

        System.out.println("Introduce el tercer número entero:");
        int num3 = num.nextInt(); // Lee el tercer número

        // Guarda los números en un array
        int[] numeros = {num1, num2, num3};  //  estructura de datos que almacena una colección de 
        									//elementos del mismo tipo de forma secuencial y con un 
        									//tamaño fijo una vez creado

        // Ordena el array en orden ascendente (de menor a mayor)
        Arrays.sort(numeros);

        // Muestra los números ordenados
        System.out.println("Los números ordenados de forma ascendente son:");
        for (int numero : numeros) {
            System.out.print(numero + " "); // Imprime cada número seguido de un espacio
        }

        num.close(); // Cierra el objeto Scanner para liberar recursos
    }
}