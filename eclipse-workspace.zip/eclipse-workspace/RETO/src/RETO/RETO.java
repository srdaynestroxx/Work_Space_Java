package RETO;

import java.io.*;//importo
import java.util.*;

public class RETO {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		File file = new File("./src/RETO/DatosIgualdad.csv");//ruta relativa( copiar y pegar el fichero en el package y poner la ruta de por donde dice ecplise arriba)
		Scanner escritura = new Scanner(System.in);
		
		String[] pais = new String[29];//29 xq so 28 paises
		String[]ubicacion = new String[29];
		double [] trabajo = new double [29];
		double[]dinero = new double[29];
		double[]conocimiento = new double[29];
		double[] tiempo = new double[29];
		double[]poder = new double[29];
		double[]salud = new double[29];
		int opcion = 0;//para el switch
		
		
		try {
			FileReader fr =new FileReader(file);
			BufferedReader br = new BufferedReader(fr);
			
//			scanner que lee fichero 
			Scanner sc = new Scanner(file);
		
			sc.next();//salta el encabezado, lo que pone el titulo de los datos 
			
			fr.close();
			br.close();
			
//			lectura linea a linea del fichero 
			while(sc.hasNext()) {
				String linea;
				linea =sc.next();
				System.out.println(linea);
			}
			
		}
		catch(IOException e) {
			
			System.out.println("error a leer "+e.getMessage());
		}
		
		do {

			System.out.println("\n"+"1-Visualización de datos por ubicación: ");
			System.out.println("2-Media de datos parámetro DINERO: ");
			System.out.println("3-Países con valor superior a la media en parámetro TIEMPO: ");
			System.out.println("4-Modificar valores país: ");
			System.out.println("5-Guardar datos en fichero: ");
			System.out.println("6-Países con menor igualdad: ");
			System.out.println("7-salir: "+"\n");
			
			
			System.out.println("selecciona una opcion del 0-7: ");
			opcion = escritura.nextInt();
			
			switch(opcion) {
		
			case 1:
				
				break;
				
			case 2:
				
				break;
				
			case 3:
				
				break;
				
			case 4:
				
				break;
				
			case 5:
				guardarDatos()
				break;
				
			case 6:
				
				break;
				
			case 7:
				System.out.println("haz salido correctamente del programa :) ");
				break;
				
				
				

			}

		}while(opcion!=0);
			
		}
	}


